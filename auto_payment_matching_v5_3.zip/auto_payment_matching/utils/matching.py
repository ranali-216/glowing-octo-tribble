"""Pure-Python helpers for the matching engine.

Nothing in this file imports Odoo, so it can be unit tested on its own.
"""
import re

YEAR_RE = re.compile(r'^(19|20)\d{2}$')
DIGITS_RE = re.compile(r'\d+')


def normalize(text):
    """Upper-case and strip everything that is not A-Z / 0-9.

    'INV/2026/00012' and 'inv-2026-00012' both become 'INV202600012'.
    """
    return re.sub(r'[^A-Z0-9]', '', (text or '').upper())


def search_tokens(text, limit=12):
    """Digit groups worth sending to the database as ``ilike`` filters.

    Years on their own (2026) are skipped because they match everything.
    For long glued numbers (INV202600012 -> 202600012) the last 5 digits are
    added too, because that is usually the sequence part of the document name.
    """
    tokens = []
    for group in DIGITS_RE.findall(text or ''):
        if len(group) < 4 or YEAR_RE.match(group):
            continue
        tokens.append(group)
        if len(group) >= 7:
            tokens.append(group[-5:])
    seen = []
    for tok in sorted(tokens, key=len, reverse=True):
        if tok not in seen:
            seen.append(tok)
    return seen[:limit]


class TextIndex:
    """Pre-processed bank text used to test many document references fast."""

    def __init__(self, text):
        self.raw = text or ''
        self.norm = normalize(self.raw)
        groups = DIGITS_RE.findall(self.raw)
        self.digit_groups = set(groups)
        self.stripped_groups = {g.lstrip('0') for g in groups if g.lstrip('0')}

    def contains_token(self, token):
        """Containment with digit boundaries, so 00012 does not hit 000123."""
        if not token:
            return False
        start = 0
        size = len(token)
        while True:
            idx = self.norm.find(token, start)
            if idx < 0:
                return False
            before = self.norm[idx - 1] if idx > 0 else ''
            after = self.norm[idx + size] if idx + size < len(self.norm) else ''
            ok_before = not (token[0].isdigit() and before.isdigit())
            ok_after = not (token[-1].isdigit() and after.isdigit())
            if ok_before and ok_after:
                return True
            start = idx + 1

    def reference_hit(self, refs):
        """Return 'strong', 'numeric' or None.

        ``refs`` = [document name, payment reference, ref]; the first entry
        must be the document name (used for the weaker numeric fallback).
        """
        for ref in refs:
            norm = normalize(ref)
            if not norm or not any(c.isdigit() for c in norm):
                continue
            if norm.isdigit():
                # Pure numbers (e.g. a vendor's own bill number) must match a
                # whole digit group, and be long enough to be meaningful.
                if len(norm) >= 5 and norm in self.digit_groups:
                    return 'strong'
                continue
            if len(norm) >= 4 and self.contains_token(norm):
                return 'strong'

        name = refs[0] if refs else ''
        groups = DIGITS_RE.findall(name or '')
        if groups:
            seq = groups[-1]
            stripped = seq.lstrip('0')
            if (
                len(seq) >= 4
                and not YEAR_RE.match(seq)
                and (
                    seq in self.digit_groups
                    or (len(stripped) >= 4 and stripped in self.stripped_groups)
                )
            ):
                return 'numeric'
        return None


def find_subset(values, target, max_items=30, max_states=200000):
    """Subset-sum on integer amounts (e.g. paisa / cents).

    ``values`` must be in order of preference (oldest first); non-positive
    values are ignored. Returns ``(indices, ambiguous)`` where ``indices`` is a
    tuple of positions into ``values`` or ``None`` when no subset adds up to
    ``target``. ``ambiguous`` is True when more than one subset reaches it.
    """
    if target <= 0:
        return None, False
    # sum -> (indices of the first subset found, number of subsets capped at 2)
    states = {0: ((), 1)}
    for i, value in enumerate(values[:max_items]):
        if value <= 0 or value > target:
            continue
        for total, (idx, count) in list(states.items()):
            new_total = total + value
            if new_total > target:
                continue
            if new_total in states:
                first, existing = states[new_total]
                states[new_total] = (first, min(2, existing + count))
            elif len(states) < max_states:
                states[new_total] = (idx + (i,), count)
    hit = states.get(target)
    if not hit:
        return None, False
    return hit[0], hit[1] > 1


def fifo_take(values, target):
    """Take values in order until ``target`` is covered. Returns indices."""
    picked = []
    total = 0
    for i, value in enumerate(values):
        if value <= 0:
            continue
        picked.append(i)
        total += value
        if total >= target:
            break
    return tuple(picked)


# ---------------------------------------------------------------------------
# Customer names (v5.3): bank statements write names differently from Odoo
# ("AL NOOR TRADERS" vs "Al-Noor Traders", "M/S PAK STEEL" vs "Pak Steel Works").
# ---------------------------------------------------------------------------
import difflib

# Legal forms and fillers that say nothing about who the customer is.
NAME_NOISE = {
    'm', 's', 'ms', 'mr', 'mrs', 'messrs', 'the', 'and', 'pvt', 'private', 'ltd', 'limited', 'co', 'company',
    'corp', 'corporation', 'inc', 'llc', 'plc', 'smc', 'enterprises', 'group',
}


def name_tokens(text):
    """Lower-case words of a name without punctuation and legal forms."""
    words = re.sub(r'[^a-z0-9]+', ' ', (text or '').lower()).split()
    return [w for w in words if w not in NAME_NOISE]


def name_similarity(bank_name, partner_name):
    """0..1 similarity of a payer name on the statement and a customer name.

    * identical after cleaning (spaces, hyphens, case, legal forms) -> 1.0
    * one name fully contained in the other with at least two words
      ("PAK STEEL" in "Pak Steel Works")                        -> 0.9
    * otherwise the best of character similarity of the glued names
      and word overlap.
    """
    a, b = name_tokens(bank_name), name_tokens(partner_name)
    if not a or not b:
        return 0.0
    ga, gb = ''.join(a), ''.join(b)
    if ga == gb:
        return 1.0
    sa, sb = set(a), set(b)
    short, long_ = (sa, sb) if len(sa) <= len(sb) else (sb, sa)
    if len(short) >= 2 and short <= long_:
        return 0.9
    char_ratio = difflib.SequenceMatcher(None, ga, gb).ratio()
    overlap = len(sa & sb) / len(sa | sb)
    return max(char_ratio, overlap)


def name_in_text(partner_name, text):
    """True when every meaningful word of the customer name appears in the text.

    Needs at least one word of 4+ letters so that short or generic names
    ("AB Co") are not found by accident.
    """
    words = name_tokens(partner_name)
    if not words or not any(len(w) >= 4 for w in words):
        return False
    text_words = set(name_tokens(text))
    glued = ''.join(name_tokens(text))
    return all(w in text_words for w in words) or (len(words) >= 2 and ''.join(words) in glued)
