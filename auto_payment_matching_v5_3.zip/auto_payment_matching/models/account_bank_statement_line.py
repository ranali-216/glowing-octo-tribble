import logging
import re
import threading
from datetime import timedelta

from markupsafe import Markup
from psycopg2 import OperationalError

from odoo import api, fields, models, Command, _
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
from odoo.tools import html2plaintext
from odoo.tools.misc import formatLang

from ..utils import matching as mu

_logger = logging.getLogger(__name__)

# Customer side only: this module never matches vendor bills.
INVOICE_TYPES = ('out_invoice', 'out_refund', 'out_receipt')
RECEIVABLE = 'asset_receivable'
OPEN_ACCOUNT_TYPES = ('asset_receivable', 'liability_payable')

# Score building blocks (sum is capped at 100).
SCORE_REF_STRONG = 55
SCORE_REF_MIXED = 45
SCORE_REF_NUMERIC = 30
SCORE_AMOUNT = {'exact': 30, 'tolerance': 20, 'partial': 10, 'overpayment': 10}
SCORE_PARTNER = 15
SCORE_UNIQUE = 10
SCORE_FIFO_BASE = 15
SCORE_NAME_FUZZY = 12      # payer name similar (not identical) or customer name found in the bank label
SCORE_DATE_OK = 6          # paid within the usual payment window after the invoice
PENALTY_FUTURE_DOC = 10    # an invoice dated after the payment
SCORE_CLOSEST_DATE = 4     # several invoices with the same amount: due date closest to the payment
NAME_MIN_SIMILARITY = 0.85


class AccountBankStatementLine(models.Model):
    _inherit = 'account.bank.statement.line'

    # ------------------------------------------------------------------
    # Fields (names of v1 fields are kept so upgrading keeps the data)
    # ------------------------------------------------------------------
    auto_match_status = fields.Selection(
        [
            ('pending', 'Pending'),
            ('suggested', 'Suggestion Ready'),
            ('matched', 'Matched'),
            ('partial', 'Partially Matched'),
            ('not_found', 'Not Found'),
            ('error', 'Error'),
            ('excluded', 'Excluded'),
        ],
        string='Auto Match Status', default='pending', copy=False, index=True,
    )
    auto_match_message = fields.Text(string='Auto Match Message', copy=False, readonly=True)
    auto_match_document_ids = fields.Many2many(
        'account.move', 'auto_payment_matching_move_rel', 'statement_line_id', 'move_id',
        string='Matched Invoices', copy=False, readonly=True,
    )
    auto_match_date = fields.Datetime(string='Last Matching Run', copy=False, readonly=True)
    auto_match_document_remaining = fields.Text(string='Document Remaining', copy=False, readonly=True)

    auto_match_payment_amount = fields.Monetary(
        string='Payment Amount', currency_field='currency_id',
        compute='_compute_apm_amounts', store=True)
    auto_match_applied_amount = fields.Monetary(
        string='Applied Amount', currency_field='currency_id',
        compute='_compute_apm_amounts', store=True)
    auto_match_remaining_amount = fields.Monetary(
        string='Remaining Amount', currency_field='currency_id',
        compute='_compute_apm_amounts', store=True)
    auto_payment_available = fields.Boolean(
        string='Available for Matching', compute='_compute_apm_amounts', store=True, index=True)

    payment_record_status = fields.Selection(
        [
            ('pending', 'Pending'),
            ('matched', 'Paid / Matched'),
            ('partial', 'Partially Paid'),
            ('not_found', 'Not Found'),
            ('error', 'Error'),
        ],
        string='Payment Status', compute='_compute_payment_record_status')
    payment_record_visible = fields.Boolean(
        string='Show in Payment Records', compute='_compute_payment_record_visibility',
        store=True, index=True)

    apm_stage = fields.Selection(
        [('pending', 'Pending'), ('partial', 'Partially Reconciled'), ('full', 'Fully Reconciled')],
        string='Stage', compute='_compute_apm_stage', store=True, index=True)
    apm_direction = fields.Selection(
        [('inbound', 'Money In'), ('outbound', 'Money Out')],
        string='Direction', compute='_compute_apm_direction', store=True)
    apm_exclude = fields.Boolean(string='Excluded from Auto Matching', copy=False)
    apm_suggestion_ids = fields.One2many('auto.match.suggestion', 'statement_line_id', string='Suggestions')
    apm_log_ids = fields.One2many('auto.match.log', 'statement_line_id', string='Activity')
    apm_best_score = fields.Integer(
        string='Best Confidence (%)', compute='_compute_apm_best_score', store=True)
    apm_duplicate_id = fields.Many2one(
        'account.bank.statement.line', string='Possible Duplicate Of', copy=False, readonly=True,
        help='An earlier transaction in the same journal with the same date, amount and label. '
             'Possible duplicates are never reconciled automatically.')
    apm_rule_id = fields.Many2one(
        'auto.match.rule', string='Proposed Rule', copy=False, readonly=True,
        help='A matching rule that fits this transaction and is waiting for confirmation.')
    apm_writeoff_move_ids = fields.Many2many(
        'account.move', 'apm_st_line_writeoff_rel', 'statement_line_id', 'move_id',
        string='Write-off Entries', copy=False, readonly=True)

    # ------------------------------------------------------------------
    # Computes
    # ------------------------------------------------------------------
    @api.depends('amount')
    def _compute_apm_direction(self):
        for line in self:
            line.apm_direction = 'outbound' if line.amount < 0 else 'inbound'

    @api.depends('auto_match_applied_amount', 'auto_match_remaining_amount')
    def _compute_apm_stage(self):
        for line in self:
            currency = line.currency_id
            if not currency or currency.is_zero(line.auto_match_applied_amount):
                line.apm_stage = 'pending'
            elif currency.is_zero(line.auto_match_remaining_amount):
                line.apm_stage = 'full'
            else:
                line.apm_stage = 'partial'

    @api.depends('apm_suggestion_ids.score', 'apm_suggestion_ids.state')
    def _compute_apm_best_score(self):
        for line in self:
            scores = line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending').mapped('score')
            line.apm_best_score = max(scores) if scores else 0

    @api.depends(
        'amount',
        'move_id.line_ids.reconciled',
        'move_id.line_ids.amount_residual',
        'move_id.line_ids.amount_residual_currency',
        'move_id.line_ids.amount_currency',
        'move_id.line_ids.account_id',
    )
    def _compute_apm_amounts(self):
        for line in self:
            total = abs(line.amount)
            remaining = 0.0
            if line.move_id:
                try:
                    _payment_line, signed = line._apm_payment_state()
                    remaining = abs(signed)
                except Exception:  # never break list views on odd entries
                    _logger.debug('APM: cannot compute remaining for %s', line.id, exc_info=True)
                    remaining = 0.0 if line.is_reconciled else total
            line.auto_match_payment_amount = total
            line.auto_match_remaining_amount = remaining
            line.auto_match_applied_amount = max(0.0, total - remaining)
            # Only money received from customers is handled by this module.
            line.auto_payment_available = (
                line.amount > 0 and bool(line.currency_id) and not line.currency_id.is_zero(remaining))

    @api.depends('is_reconciled', 'auto_match_status')
    def _compute_payment_record_status(self):
        for line in self:
            if line.is_reconciled and line.auto_match_status != 'partial':
                line.payment_record_status = 'matched'
            elif line.auto_match_status in ('matched', 'partial', 'not_found', 'error'):
                line.payment_record_status = line.auto_match_status
            else:
                line.payment_record_status = 'pending'

    @api.depends('is_reconciled', 'auto_match_status')
    def _compute_payment_record_visibility(self):
        for line in self:
            line.payment_record_visible = bool(
                line.is_reconciled or line.auto_match_status in ('matched', 'partial'))

    # ------------------------------------------------------------------
    # Low level helpers
    # ------------------------------------------------------------------
    def _apm_cfg(self):
        return self.env['res.config.settings']._apm_config()

    def _apm_line_residual(self, aml):
        """Residual of a journal item in the bank transaction currency."""
        self.ensure_one()
        if aml.currency_id == self.currency_id:
            return aml.amount_residual_currency
        return aml.amount_residual

    def _apm_is_supported(self):
        self.ensure_one()
        if self.amount < 0:
            return False, _('Payment Matching handles money received from customers only; '
                            'outgoing payments are not matched here.')
        if self.foreign_currency_id:
            return False, _(
                'This transaction is in a foreign currency. Please reconcile it '
                'from the standard Odoo bank reconciliation screen so exchange '
                'differences are booked correctly.')
        return True, ''

    def _apm_payment_state(self):
        """Return ``(payment_lines, remaining)``.

        ``remaining`` uses the sign of the bank amount: positive means money
        received that is still unallocated, negative means money paid out that
        is still unallocated.

        * First allocation: the open amount sits on the suspense line. Suspense
          accounts are often not reconcilable, so their residual is 0 and the
          ``amount_currency`` is used instead.
        * Later allocations: the counterpart was moved to the partner's
          receivable/payable account; its live residual is used.
        """
        self.ensure_one()
        empty = self.env['account.move.line']
        if not self.move_id:
            return empty, 0.0
        liquidity, suspense, other = self._seek_for_lines()
        if suspense:
            field = 'amount_residual_currency' if suspense[:1].account_id.reconcile else 'amount_currency'
            return suspense, -sum(suspense.mapped(field))

        counterpart = other.filtered(
            lambda l: l.account_id.account_type in OPEN_ACCOUNT_TYPES
            and not l.reconciled
            and not self.currency_id.is_zero(self._apm_line_residual(l)))
        if not counterpart:
            counterpart = (self.move_id.line_ids - liquidity).filtered(
                lambda l: l.account_id.reconcile
                and not l.reconciled
                and not self.currency_id.is_zero(self._apm_line_residual(l)))
        if not counterpart:
            return empty, 0.0
        return counterpart, -sum(self._apm_line_residual(l) for l in counterpart)

    def _apm_text(self):
        self.ensure_one()
        parts = [self.payment_ref, self.move_id.ref]
        if self.narration:
            parts.append(html2plaintext(self.narration))
        return ' '.join(p for p in parts if p)

    def _apm_base_aml_domain(self):
        self.ensure_one()
        domain = [
            ('company_id', '=', self.company_id.id),
            ('parent_state', '=', 'posted'),
            ('reconciled', '=', False),
            ('account_id.reconcile', '=', True),
            ('account_id.account_type', '=', RECEIVABLE),
            ('currency_id', '=', self.currency_id.id),
            ('move_id', '!=', self.move_id.id),
            ('amount_residual_currency', '!=', 0.0),
        ]
        if not self._apm_cfg().include_misc_entries:
            domain.append(('move_id.move_type', 'in', INVOICE_TYPES))
        return domain

    def _apm_resolve_partner(self):
        """Backwards compatible: (partner, source label)."""
        partner, label, _points = self._apm_identify()
        return partner, label

    def _apm_open_customers(self):
        """Commercial partners that currently have open customer invoices."""
        self.ensure_one()
        groups = self.env['account.move.line']._read_group(
            self._apm_base_aml_domain(), ['partner_id'], ['__count'])
        return self.env['res.partner'].union(*[p.commercial_partner_id for p, _c in groups if p])

    def _apm_identify(self):
        """Find the customer independently of the invoices.

        Returns (commercial partner, how it was found, points). Exact signals
        (bank line, bank account, exact or learned name) give 15 points; a
        similar payer name or the customer name inside the bank label give 12.
        """
        self.ensure_one()
        Partner = self.env['res.partner']
        Learned = self.env['auto.match.learned.partner']
        override = self.env.context.get('apm_partner_override')
        if override:
            return Partner.browse(override).commercial_partner_id, _('matching rule'), SCORE_PARTNER
        if self.partner_id:
            return self.partner_id.commercial_partner_id, _('bank line partner'), SCORE_PARTNER

        if self.account_number:
            sanitized = re.sub(r'\W+', '', self.account_number).upper()
            banks = self.env['res.partner.bank'].search([('sanitized_acc_number', '=', sanitized)], limit=5)
            partners = banks.partner_id.commercial_partner_id
            if len(partners) == 1:
                return partners, _('bank account number'), SCORE_PARTNER
            learned = Learned._apm_lookup('account_number', self.account_number, self.company_id)
            if learned:
                return learned.commercial_partner_id, _('learned bank account'), SCORE_PARTNER

        payer = (self.partner_name or '').strip()
        if payer:
            # '%' and '_' are wildcards for =ilike: escape them for an exact comparison
            exact_name = payer.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
            found = Partner.search([
                ('name', '=ilike', exact_name),
                '|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
            ], limit=5).commercial_partner_id
            if len(found) == 1:
                return found, _('payer name'), SCORE_PARTNER
            learned = Learned._apm_lookup('partner_name', payer, self.company_id)
            if learned:
                return learned.commercial_partner_id, _('learned payer name'), SCORE_PARTNER

        customers = self._apm_open_customers() if (payer or self.payment_ref) else Partner
        if payer and customers:
            scored = sorted(((mu.name_similarity(payer, c.name), c) for c in customers),
                            key=lambda x: -x[0])
            best_sim, best = scored[0]
            runner_up = scored[1][0] if len(scored) > 1 else 0.0
            # only when clearly one customer: a near tie means we do not know
            if best_sim >= NAME_MIN_SIMILARITY and best_sim - runner_up >= 0.05:
                return best, _('payer name, %s%% similar') % int(round(best_sim * 100)), SCORE_NAME_FUZZY
        if customers:
            text = self._apm_text()
            in_label = customers.filtered(lambda c: mu.name_in_text(c.name, text))
            if len(in_label) == 1:
                return in_label, _('customer name in the bank label'), SCORE_NAME_FUZZY
        return Partner, '', 0

    def _apm_collect_candidates(self, partner):
        self.ensure_one()
        AML = self.env['account.move.line']
        base = self._apm_base_aml_domain()
        candidates = AML
        tokens = mu.search_tokens(self._apm_text())
        if tokens:
            or_domains = []
            for tok in tokens:
                or_domains += [
                    [('move_id.name', 'ilike', tok)],
                    [('move_id.ref', 'ilike', tok)],
                    [('move_id.payment_reference', 'ilike', tok)],
                ]
            candidates |= AML.search(expression.AND([base, expression.OR(or_domains)]), limit=300)
        if partner:
            candidates |= AML.search(
                base + [('partner_id', 'child_of', partner.id)],
                order='date_maturity asc, date asc, id asc', limit=200)
        return candidates

    @staticmethod
    def _apm_fifo_key(aml):
        return (aml.date_maturity or aml.date, aml.date, aml.id)

    # ------------------------------------------------------------------
    # Matching engine
    # ------------------------------------------------------------------
    def _apm_find_proposals(self):
        """Return ``(proposals, notes)``; proposals are sorted best first."""
        self.ensure_one()
        currency = self.currency_id
        notes = []
        _payment_lines, remaining = self._apm_payment_state()
        if currency.is_zero(remaining):
            return [], [_('Nothing left to allocate.')]
        sign = 1 if remaining > 0 else -1
        factor = 10 ** currency.decimal_places
        cfg = self._apm_cfg()
        tolerance = cfg.writeoff_tolerance if cfg.writeoff_account_id else 0.0

        partner, partner_source, partner_points = self._apm_identify()
        candidates = self._apm_collect_candidates(partner)
        index = mu.TextIndex(self._apm_text())

        def res(aml):
            return self._apm_line_residual(aml)

        def cents(value):
            return int(round(value * sign * factor))

        def closeness(aml):
            due = aml.date_maturity or aml.date
            return abs((due - self.date).days)

        def build(amls, strategy, ref_score, reasons, extra=()):
            amls = amls.sorted(self._apm_fifo_key)
            total = sum(res(l) for l in amls)
            if total * sign <= 0 or currency.is_zero(total):
                return None
            diff = total - remaining
            if currency.is_zero(diff):
                kind = 'exact'
            elif tolerance and abs(diff) <= tolerance + currency.rounding / 2:
                kind = 'tolerance'
            elif diff * sign > 0:
                kind = 'partial'
            else:
                kind = 'overpayment'
            doc_partner = amls.partner_id.commercial_partner_id[:1]
            score = ref_score + SCORE_AMOUNT[kind]
            reasons = list(reasons)
            reasons.append(dict(AMOUNT_LABELS)[kind])
            if partner and doc_partner == partner:
                score += partner_points
                reasons.append(_('Customer confirmed by %s') % partner_source)
            if strategy == 'partner_fifo':
                score += SCORE_FIFO_BASE
            # date: the payment should come after the invoice, within the usual window
            inv_dates = [l.invoice_date or l.date for l in amls]
            if any(d > self.date for d in inv_dates):
                score -= PENALTY_FUTURE_DOC
                reasons.append(_('An invoice is dated after the payment'))
            else:
                days = (self.date - max(inv_dates)).days
                if days <= cfg.payment_window_days:
                    score += SCORE_DATE_OK
                    reasons.append(_('Paid %s days after the invoice, within the payment window') % days)
                else:
                    reasons.append(_('Paid %s days after the invoice, later than usual') % days)
            for pts, why in extra:
                score += pts
                reasons.append(why)
            return {
                'amls': amls,
                'strategy': strategy,
                'kind': kind,
                'score': max(0, min(100, score)),
                'reasons': reasons,
                'partner': doc_partner,
                'total': total,
                'diff': diff,
            }

        proposals = []

        # 1. Reference based ------------------------------------------------
        hits = {}
        for aml in candidates:
            move = aml.move_id
            hit = index.reference_hit([move.name, move.payment_reference, move.ref])
            if hit:
                hits[aml.id] = hit
        hit_lines = candidates.filtered(lambda l: l.id in hits)
        groups = {}
        for aml in hit_lines:
            groups.setdefault((aml.partner_id.commercial_partner_id.id, aml.account_id.id),
                              self.env['account.move.line'])
            groups[(aml.partner_id.commercial_partner_id.id, aml.account_id.id)] |= aml
        for group in groups.values():
            kinds = {hits[l.id] for l in group}
            if kinds == {'strong'}:
                ref_score = SCORE_REF_STRONG
            elif 'strong' in kinds:
                ref_score = SCORE_REF_MIXED
            else:
                ref_score = SCORE_REF_NUMERIC
            names = ', '.join(group.move_id.mapped('name'))
            proposal = build(group, 'reference', ref_score, [_('Reference found: %s') % names])
            if proposal:
                proposals.append(proposal)
            if (not proposal or proposal['kind'] != 'exact') and len(group) > 1:
                ordered = group.sorted(self._apm_fifo_key)
                idx, ambiguous = mu.find_subset([cents(res(l)) for l in ordered], cents(remaining))
                if idx and not ambiguous:
                    subset = self.env['account.move.line'].concat(*[ordered[i] for i in idx])
                    sub = build(subset, 'reference_subset', SCORE_REF_MIXED,
                                [_('Some referenced documents add up to the payment')])
                    if sub:
                        proposals.append(sub)

        # 2. Partner based --------------------------------------------------
        if partner:
            partner_lines = candidates.filtered(
                lambda l: l.partner_id.commercial_partner_id == partner)
            by_account = {}
            for aml in partner_lines:
                by_account.setdefault(aml.account_id.id, self.env['account.move.line'])
                by_account[aml.account_id.id] |= aml
            for lines in by_account.values():
                ordered = lines.sorted(self._apm_fifo_key)
                exact = ordered.filtered(lambda l: currency.is_zero(res(l) - remaining))
                if len(exact) == 1:
                    proposal = build(exact, 'partner_exact', 0,
                                     [_('Only open document of this partner with this amount')])
                    if proposal:
                        proposals.append(proposal)
                    continue
                if len(exact) > 1:
                    notes.append(_('%s open invoices of %s have exactly this amount.')
                                 % (len(exact), partner.display_name))
                    ranked = exact.sorted(lambda l: (closeness(l), l.id))
                    for i, aml in enumerate(ranked[:3]):
                        extra = [(SCORE_CLOSEST_DATE, _('Due date closest to the payment date'))] if i == 0 else []
                        proposal = build(aml, 'partner_exact', 0,
                                         [_('Same amount as other open invoices of the customer')], extra)
                        if proposal:
                            proposals.append(proposal)
                    continue
                direction = ordered.filtered(lambda l: res(l) * sign > 0)
                idx, ambiguous = mu.find_subset([cents(res(l)) for l in direction], cents(remaining))
                if idx:
                    subset = self.env['account.move.line'].concat(*[direction[i] for i in idx])
                    penalty = 5 if ambiguous else 0
                    reason = (_('Several invoice combinations match; oldest chosen') if ambiguous
                              else _('Open documents add up exactly to the payment'))
                    proposal = build(subset, 'partner_combination', -penalty, [reason])
                    if proposal:
                        proposals.append(proposal)
                    continue
                if cfg.partner_fifo and direction:
                    idx = mu.fifo_take([cents(res(l)) for l in direction], cents(remaining))
                    subset = self.env['account.move.line'].concat(*[direction[i] for i in idx])
                    proposal = build(subset, 'partner_fifo', 0,
                                     [_('Oldest open documents of the partner')])
                    if proposal:
                        proposals.append(proposal)

        # 3. Unique amount (no reference, no partner) -----------------------
        if not proposals and not partner:
            half = currency.rounding / 2
            same_amount = self.env['account.move.line'].search(
                self._apm_base_aml_domain() + [
                    ('amount_residual_currency', '>=', remaining - half),
                    ('amount_residual_currency', '<=', remaining + half),
                ], limit=6)
            if len(same_amount) == 1:
                proposal = build(same_amount, 'global_exact', 0,
                                 [_('Only open invoice in the company with this amount'),
                                  _('No customer details on the statement')])
                if proposal:
                    proposals.append(proposal)
            elif 1 < len(same_amount) <= 5:
                notes.append(_('%s open invoices have this amount and nothing identifies the payer; '
                               'the one due closest to the payment date is suggested.') % len(same_amount))
                ranked = same_amount.sorted(lambda l: (closeness(l), l.id))
                for i, aml in enumerate(ranked[:3]):
                    extra = [(SCORE_CLOSEST_DATE, _('Due date closest to the payment date'))] if i == 0 else []
                    proposal = build(aml, 'global_exact', 0,
                                     [_('Same amount as other open invoices'),
                                      _('No customer details on the statement')], extra)
                    if proposal:
                        proposals.append(proposal)
            elif len(same_amount) > 5:
                notes.append(_('Many open invoices have this amount and nothing identifies the payer.'))

        # Deduplicate (same set of items) keeping the best score.
        best = {}
        for proposal in proposals:
            key = frozenset(proposal['amls'].ids)
            if key not in best or proposal['score'] > best[key]['score']:
                best[key] = proposal
        proposals = sorted(best.values(), key=lambda p: (-p['score'], len(p['amls'])))
        if proposals and (len(proposals) == 1 or proposals[1]['score'] <= proposals[0]['score'] - 10):
            proposals[0]['score'] = min(100, proposals[0]['score'] + SCORE_UNIQUE)
            proposals[0]['reasons'].append(_('No competing match'))
        if not proposals and not notes:
            notes.append(_('No reference, partner or unique amount could be found.'))
        return proposals, notes

    def _apm_run(self, allow_apply=True):
        """Run matching for one line. ``allow_apply`` lets confident matches reconcile."""
        self.ensure_one()
        if self.apm_exclude:
            return
        supported, msg = self._apm_is_supported()
        if not supported:
            self._apm_set_result('not_found', msg)
            return
        _lines, remaining = self._apm_payment_state()
        if self.currency_id.is_zero(remaining):
            self._apm_set_result('matched', _('Nothing left to allocate; this payment is fully reconciled.'))
            return

        cfg = self._apm_cfg()
        self.apm_rule_id = False

        # Duplicate guard: the same transaction imported twice must never be
        # reconciled automatically.
        duplicate = self.search([
            ('id', '<', self.id),
            ('journal_id', '=', self.journal_id.id),
            ('date', '=', self.date),
            ('amount', '=', self.amount),
            ('payment_ref', '=', self.payment_ref),
        ], limit=1)
        self.apm_duplicate_id = duplicate
        if duplicate:
            allow_apply = False

        # User-defined rules come first.
        matcher = self
        rule = self.env['auto.match.rule']._apm_find(self) if cfg.use_rules else self.env['auto.match.rule']
        if rule:
            if rule.action == 'exclude':
                rule._apm_hit()
                self.action_apm_exclude()
                self.auto_match_message = _('Excluded by rule "%s".') % rule.name
                return
            if rule.action == 'book':
                if allow_apply and rule.auto_apply:
                    self._apm_book_with_rule(rule)
                else:
                    self.apm_rule_id = rule
                    self._apm_set_result('suggested', _(
                        'Rule "%(rule)s" proposes booking this to %(account)s. Use "Apply Rule" to confirm.',
                        rule=rule.name, account=rule.account_id.display_name))
                return
            if rule.action == 'partner' and rule.partner_id:
                rule._apm_hit()
                matcher = self.with_context(apm_partner_override=rule.partner_id.id)

        proposals, notes = matcher._apm_find_proposals()
        if duplicate:
            notes.append(_('Possible duplicate of %s: auto-reconciliation skipped.') % duplicate.display_name)
        self.apm_suggestion_ids.filtered(lambda s: s.state == 'pending').unlink()
        keep = [p for p in proposals if p['score'] >= cfg.suggest_threshold][:3]
        suggestions = self.env['auto.match.suggestion'].create([{
            'statement_line_id': self.id,
            'partner_id': p['partner'].id,
            'move_line_ids': [Command.set(p['amls'].ids)],
            'document_total': abs(p['total']),
            'difference': abs(p['diff']),
            'score': p['score'],
            'strategy': p['strategy'],
            'amount_kind': p['kind'],
            'reasons': '\n'.join('- %s' % r for r in p['reasons']),
        } for p in keep])

        best = suggestions.sorted(lambda s: -s.score)[:1]
        if (allow_apply and best and cfg.mode == 'confident'
                and best.score >= cfg.auto_threshold):
            best._apply(source='auto')
            return
        if suggestions:
            message = _('%(count)s suggestion(s) ready. Best confidence: %(score)s%%.',
                        count=len(suggestions), score=best.score)
            if duplicate:
                message += ' ' + notes[-1]
            self._apm_set_result('suggested', message)
        else:
            self._apm_set_result('not_found', '\n'.join(notes) or _('No match found.'))

    def _apm_book_with_rule(self, rule):
        """Post the whole open amount to the rule's account. Never raises."""
        self.ensure_one()
        try:
            with self.env.cr.savepoint():
                payment_lines, remaining = self._apm_payment_state()
                if len(payment_lines) != 1 or self.currency_id.is_zero(remaining):
                    raise UserError(_('This transaction has no single open amount to book.'))
                if payment_lines.matched_debit_ids or payment_lines.matched_credit_ids:
                    raise UserError(_('Part of this transaction is already allocated; '
                                      'undo it first or match the rest manually.'))
                if rule.account_id.company_id and rule.account_id.company_id != self.company_id:
                    raise UserError(_('The rule account belongs to another company.'))
                vals = {'account_id': rule.account_id.id}
                if rule.partner_id:
                    vals['partner_id'] = rule.partner_id.id
                if rule.label:
                    vals['name'] = rule.label
                payment_lines.with_context(
                    check_move_validity=False, skip_readonly_check=True, tracking_disable=True,
                ).write(vals)
        except OperationalError:
            raise  # let Odoo retry the request
        except Exception as exc:  # recorded, not raised
            if not isinstance(exc, (UserError, ValidationError)):
                _logger.exception('APM: rule booking failed for statement line %s', self.id)
            message = exc.args[0] if exc.args else str(exc)
            return self._apm_record_failure(message, self.env['account.move.line'], 'rule', None)

        rule._apm_hit()
        message = _('Booked %(amount)s to %(account)s by rule "%(rule)s".',
                    amount=formatLang(self.env, abs(remaining), currency_obj=self.currency_id),
                    account=rule.account_id.display_name, rule=rule.name)
        self.apm_rule_id = False
        self._apm_set_result('matched', message)
        self.env['auto.match.log'].sudo().create({
            'statement_line_id': self.id,
            'action': 'rule',
            'status': 'success',
            'amount_applied': abs(remaining),
            'remaining_amount': 0.0,
            'message': message,
        })
        return True, message

    def action_apm_apply_rule(self):
        results = []
        for line in self.filtered('apm_rule_id'):
            ok, message = line._apm_book_with_rule(line.apm_rule_id)
            if not ok and len(self) == 1:
                raise UserError(message)
            results.append(ok)
        return True

    # ------------------------------------------------------------------
    # Reconciliation
    # ------------------------------------------------------------------
    def _apm_apply(self, amls, source='manual', suggestion=None, writeoff=None, keep_order=False):
        """Reconcile the bank transaction with ``amls``. Never raises.

        Everything runs inside a savepoint, so a failure leaves the database
        exactly as it was and the error is recorded on the line.
        Returns ``(success, message)``.
        """
        self.ensure_one()
        try:
            with self.env.cr.savepoint():
                result = self._apm_apply_unsafe(amls, writeoff=writeoff, keep_order=keep_order)
        except (UserError, ValidationError) as exc:
            return self._apm_record_failure(exc.args[0] if exc.args else str(exc), amls, source, suggestion)
        except OperationalError:
            raise  # serialization failure / lock timeout: let Odoo retry the request
        except Exception as exc:
            _logger.exception('APM: reconciliation failed for statement line %s', self.id)
            return self._apm_record_failure(str(exc), amls, source, suggestion)

        status, message, documents, applied, remaining, writeoffs = result
        self._apm_set_result(status, message, documents)
        if writeoffs:
            self.apm_writeoff_move_ids = [Command.link(m.id) for m in writeoffs]
        self.env['auto.match.log'].sudo().create({
            'statement_line_id': self.id,
            'action': source,
            'status': 'success' if status == 'matched' else 'partial',
            'score': suggestion.score if suggestion else 0,
            'move_ids': [Command.set(documents.ids)],
            'writeoff_move_ids': [Command.set(writeoffs.ids)],
            'amount_applied': applied,
            'remaining_amount': remaining,
            'message': message,
        })
        if suggestion:
            suggestion.write({'state': 'applied', 'message': message})
        if source in ('manual', 'suggestion') and not self.partner_id:
            self.env['auto.match.learned.partner'].sudo()._apm_learn(
                self, documents.commercial_partner_id[:1])
        return True, message

    def _apm_record_failure(self, message, amls, source, suggestion):
        text = _('Reconciliation failed: %s') % message
        self._apm_set_result('error', text)
        self.env['auto.match.log'].sudo().create({
            'statement_line_id': self.id,
            'action': source,
            'status': 'failed',
            'score': suggestion.score if suggestion else 0,
            'move_ids': [Command.set(amls.exists().move_id.ids)],
            'message': text,
        })
        if suggestion:
            suggestion.write({'state': 'failed', 'message': text})
        return False, text

    def _apm_apply_unsafe(self, amls, writeoff=None, keep_order=False):
        self.ensure_one()
        currency = self.currency_id
        company = self.company_id
        cfg = self._apm_cfg()
        supported, msg = self._apm_is_supported()
        if not supported:
            raise UserError(msg)

        amls = amls.exists().filtered(lambda l: not l.reconciled)
        if not amls:
            raise UserError(_('The selected documents are already fully paid.'))
        invalid = amls.filtered(
            lambda l: l.parent_state != 'posted'
            or l.company_id != company
            or not l.account_id.reconcile
            or l.move_id == self.move_id)
        if invalid:
            raise UserError(_('These items cannot be used: %s') % ', '.join(invalid.move_id.mapped('name')))
        if any(l.currency_id != currency for l in amls):
            raise UserError(_('All documents must be in %s, the currency of the bank journal.') % currency.name)
        if any(l.account_id.account_type != RECEIVABLE for l in amls):
            raise UserError(_('Only customer invoices and customer credit notes can be matched here.'))
        if len(amls.account_id) != 1:
            raise UserError(_('The invoices use different receivable accounts and cannot be settled together.'))
        partners = amls.partner_id.commercial_partner_id
        if len(partners) > 1:
            raise UserError(_('All invoices must belong to the same customer.'))
        partner = partners[:1]
        target_account = amls.account_id

        payment_lines, remaining = self._apm_payment_state()
        if len(payment_lines) != 1:
            raise UserError(_(
                'Could not identify a single open payment line on this bank '
                'transaction (found %s). Please use the standard reconciliation screen.')
                % len(payment_lines))
        payment_line = payment_lines
        if currency.is_zero(remaining):
            raise UserError(_('This bank transaction has nothing left to allocate.'))
        sign = 1 if remaining > 0 else -1
        net = sum(self._apm_line_residual(l) for l in amls)
        if currency.is_zero(net) or net * sign < 0:
            raise UserError(_(
                'The selected credit notes are larger than the invoices; there is nothing to pay.'))

        before = {l.id: self._apm_line_residual(l) for l in amls}

        # 1. Put the payment side on the documents' receivable/payable account.
        write_ctx = dict(check_move_validity=False, skip_readonly_check=True, tracking_disable=True)
        if payment_line.account_id != target_account:
            if payment_line.matched_debit_ids or payment_line.matched_credit_ids:
                raise UserError(_(
                    'The remaining payment is already partly reconciled on %s; the '
                    'documents must use that same account.') % payment_line.account_id.display_name)
            payment_line.with_context(**write_ctx).write({
                'account_id': target_account.id,
                'partner_id': partner.id or payment_line.partner_id.id,
            })
        elif partner and not payment_line.partner_id:
            payment_line.with_context(**write_ctx).write({'partner_id': partner.id})

        # 2. Credit notes first (net them against the invoices they reduce).
        offsetting = amls.filtered(lambda l: self._apm_line_residual(l) * sign < 0)
        settle = amls - offsetting
        if not keep_order:
            settle = settle.sorted(self._apm_fifo_key)
        if offsetting:
            (offsetting | settle).reconcile()

        # 3. Allocate the payment document by document (oldest first unless
        #    the user ordered them), so the last one is the partial one.
        for aml in settle:
            if aml.reconciled:
                continue
            if payment_line.reconciled or currency.is_zero(self._apm_line_residual(payment_line)):
                break
            (payment_line | aml).reconcile()

        # 4. Optional write-off of small leftovers on touched items only.
        writeoffs = self.env['account.move']
        if writeoff is None:
            writeoff = cfg.writeoff_enabled
        if writeoff:
            if not cfg.writeoff_account_id:
                raise UserError(_('Set a Payment Difference Account in the settings first.'))
            tolerance = cfg.writeoff_tolerance + currency.rounding / 2
            touched = payment_line | amls.filtered(
                lambda l: not currency.is_zero(self._apm_line_residual(l) - before[l.id]))
            for aml in touched:
                left = self._apm_line_residual(aml)
                if not aml.reconciled and not currency.is_zero(left) and abs(left) <= tolerance:
                    writeoffs |= self._apm_create_writeoff(aml)

        # 5. Result.
        _lines, remaining_after = self._apm_payment_state()
        applied = abs(remaining) - abs(remaining_after)
        documents = amls.move_id
        unpaid = documents.filtered(lambda m: not m.currency_id.is_zero(m.amount_residual))
        status = 'matched' if currency.is_zero(remaining_after) and not unpaid else 'partial'
        names = ', '.join(documents.mapped('name'))
        fmt = lambda v: formatLang(self.env, abs(v), currency_obj=currency)  # noqa: E731
        if status == 'matched':
            message = _('Reconciled %(amount)s with %(docs)s.', amount=fmt(applied), docs=names)
        else:
            parts = [_('Applied %(amount)s to %(docs)s.', amount=fmt(applied), docs=names)]
            if not currency.is_zero(remaining_after):
                parts.append(_('Unallocated payment: %s (kept open on the partner).') % fmt(remaining_after))
            if unpaid:
                parts.append(_('Still open: %s.') % ', '.join(
                    '%s (%s)' % (m.name, fmt(m.amount_residual)) for m in unpaid))
            message = ' '.join(parts)
        if writeoffs:
            message += ' ' + _('Write-off: %s.') % ', '.join(writeoffs.mapped('name'))
        return status, message, documents, applied, abs(remaining_after), writeoffs

    def _apm_create_writeoff(self, aml):
        self.ensure_one()
        company = self.company_id
        cfg = self._apm_cfg()
        if cfg.writeoff_account_id.company_id and cfg.writeoff_account_id.company_id != company:
            raise UserError(_('The payment difference account belongs to another company.'))
        journal = cfg.writeoff_journal_id if cfg.writeoff_journal_id.company_id == company else self.env['account.journal']
        journal = journal or self.env['account.journal'].search(
            [('type', '=', 'general'), ('company_id', '=', company.id)], limit=1)
        if not journal:
            raise UserError(_('No miscellaneous journal found for the write-off.'))
        residual_currency = aml.amount_residual_currency
        residual = aml.amount_residual
        label = _('Payment difference: %s') % (self.payment_ref or self.move_id.name)
        move = self.env['account.move'].create({
            'move_type': 'entry',
            'journal_id': journal.id,
            'date': self.date,
            'ref': label,
            'line_ids': [
                Command.create({
                    'name': label,
                    'account_id': aml.account_id.id,
                    'partner_id': aml.partner_id.id,
                    'currency_id': aml.currency_id.id,
                    'amount_currency': -residual_currency,
                    'balance': -residual,
                }),
                Command.create({
                    'name': label,
                    'account_id': cfg.writeoff_account_id.id,
                    'partner_id': aml.partner_id.id,
                    'currency_id': aml.currency_id.id,
                    'amount_currency': residual_currency,
                    'balance': residual,
                }),
            ],
        })
        move.action_post()
        counterpart = move.line_ids.filtered(lambda l: l.account_id == aml.account_id)
        (counterpart | aml).reconcile()
        return move

    def _apm_document_snapshot(self, documents):
        self.ensure_one()
        return '\n'.join(
            '%s: %s' % (doc.name, formatLang(self.env, doc.amount_residual, currency_obj=doc.currency_id))
            for doc in documents)

    def _apm_set_result(self, status, message, documents=None):
        self.ensure_one()
        vals = {
            'auto_match_status': status,
            'auto_match_message': message,
            'auto_match_date': fields.Datetime.now(),
        }
        if documents:
            vals['auto_match_document_ids'] = [Command.link(d.id) for d in documents]
        self.write(vals)
        if documents:
            self.auto_match_document_remaining = self._apm_document_snapshot(self.auto_match_document_ids)
        if status in ('matched', 'partial', 'error') and self.move_id:
            try:
                self.move_id.message_post(
                    body=Markup('<b>%s</b><br/>%s') % (_('Auto Payment Matching'), message),
                    subtype_xmlid='mail.mt_note')
            except Exception:
                _logger.debug('APM: could not post chatter note on %s', self.move_id.id, exc_info=True)

    # ------------------------------------------------------------------
    # Buttons
    # ------------------------------------------------------------------
    def action_auto_match(self):
        counts = {}
        for line in self:
            line._apm_run(allow_apply=True)
            counts[line.auto_match_status] = counts.get(line.auto_match_status, 0) + 1
        labels = dict(self._fields['auto_match_status']._description_selection(self.env))
        summary = ', '.join('%s: %s' % (labels.get(k, k), v) for k, v in counts.items())
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Auto Payment Matching'),
                'message': _('%(n)s transaction(s) processed. %(s)s', n=len(self), s=summary),
                'type': 'warning' if counts.get('error') else 'success',
                'sticky': False,
                'next': {'type': 'ir.actions.client', 'tag': 'soft_reload'},
            },
        }

    def action_apm_open_manual(self):
        self.ensure_one()
        supported, msg = self._apm_is_supported()
        if not supported:
            raise UserError(msg)
        if not self.auto_payment_available:
            raise UserError(_('This bank transaction has nothing left to allocate.'))
        return {
            'type': 'ir.actions.act_window',
            'name': _('Match Payment'),
            'res_model': 'auto.match.manual.wizard',
            'view_mode': 'form',
            'views': [(False, 'form')],  # required when the workspace opens it through RPC
            'target': 'new',
            'context': {'default_statement_line_id': self.id},
        }

    def action_apm_undo(self):
        for line in self:
            writeoffs = line.apm_writeoff_move_ids.filtered(lambda m: m.state == 'posted')
            documents = line.auto_match_document_ids
            line.action_undo_reconciliation()
            for move in writeoffs:
                move.line_ids.remove_move_reconcile()
                move._reverse_moves(
                    [{'ref': _('Reversal of %s') % move.name, 'date': fields.Date.context_today(line)}],
                    cancel=True)
            line.apm_suggestion_ids.filtered(lambda s: s.state in ('pending', 'applied')).write({'state': 'undone'})
            line.write({
                'auto_match_status': 'pending',
                'auto_match_message': _('Reconciliation undone by %s.') % self.env.user.name,
                'auto_match_document_ids': [Command.clear()],
                'auto_match_document_remaining': False,
                'apm_writeoff_move_ids': [Command.clear()],
                'apm_rule_id': False,
            })
            self.env['auto.match.log'].sudo().create({
                'statement_line_id': line.id,
                'action': 'undo',
                'status': 'info',
                'move_ids': [Command.set(documents.ids)],
                'writeoff_move_ids': [Command.set(writeoffs.ids)],
                'message': line.auto_match_message,
            })
        return True

    def action_apm_exclude(self):
        self.write({'apm_exclude': True, 'auto_match_status': 'excluded'})
        self.apm_suggestion_ids.filtered(lambda s: s.state == 'pending').write({'state': 'rejected'})
        return True

    def action_apm_include(self):
        self.write({'apm_exclude': False, 'auto_match_status': 'pending'})
        return True

    @api.model
    def _apm_cleanup_outgoing(self):
        """Run on every install/upgrade.

        1. Recompute the stored amounts and stage of every bank line, so values
           written by an older version can never disagree with each other
           (e.g. applied 15,000 + remaining 5,000 on a 15,000 payment).
        2. Money-out lines are not handled: retire their pending suggestions.
        """
        lines = self.with_context(active_test=False).search([])
        for start in range(0, len(lines), 1000):
            batch = lines[start:start + 1000]
            for name in ('auto_match_payment_amount', 'auto_match_applied_amount',
                         'auto_match_remaining_amount', 'auto_payment_available'):
                self.env.add_to_compute(self._fields[name], batch)
            self.env.flush_all()
            self.env.add_to_compute(self._fields['apm_stage'], batch)
            self.env.flush_all()
        self.env['auto.match.suggestion'].search([
            ('state', '=', 'pending'), ('statement_line_id.amount', '<', 0),
        ]).write({'state': 'rejected', 'message': _('Outgoing payments are not handled by Payment Matching.')})
        return True

    # ------------------------------------------------------------------
    # Scheduled job
    # ------------------------------------------------------------------
    @api.model
    def _cron_apm_run(self, limit=300):
        retry_before = fields.Datetime.now() - timedelta(hours=20)
        lines = self.search([
            ('auto_payment_available', '=', True),
            ('apm_exclude', '=', False),
            ('foreign_currency_id', '=', False),
            ('auto_match_status', 'in', ('pending', 'not_found', 'suggested', 'error')),
            '|', ('auto_match_date', '=', False), ('auto_match_date', '<', retry_before),
        ], order='date desc, id desc', limit=limit)
        cfg = self._apm_cfg()
        # housekeeping: decided suggestions older than 30 days carry no information
        self.env['auto.match.suggestion'].sudo().search([
            ('state', 'in', ('rejected', 'superseded', 'failed', 'undone')),
            ('create_date', '<', fields.Datetime.now() - timedelta(days=30))]).unlink()
        testing = getattr(threading.current_thread(), 'testing', False)
        for i, line in enumerate(lines, 1):
            line._apm_run(allow_apply=cfg.cron_auto_apply)
            if not testing and i % 25 == 0:
                self.env.cr.commit()
        _logger.info('APM cron processed %s bank transaction(s).', len(lines))
        return True


AMOUNT_LABELS = [
    ('exact', 'Amount matches exactly'),
    ('tolerance', 'Amount matches within write-off tolerance'),
    ('partial', 'Partial payment of the documents'),
    ('overpayment', 'Payment exceeds the documents; the rest stays open'),
]
