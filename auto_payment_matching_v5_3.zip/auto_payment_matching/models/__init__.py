from . import res_config_settings
from . import auto_match_records
from . import auto_match_rule
from . import account_bank_statement_line
from . import ir_ui_menu
from . import apm_workspace
