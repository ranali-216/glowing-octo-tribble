from odoo import api, models


class IrUiMenu(models.Model):
    _inherit = 'ir.ui.menu'

    @api.model
    def _apm_place_menu(self):
        """Put our menu in the top bar of the Accounting app.

        Odoo 17 Enterprise has its own "Accounting" root menu (from
        account_accountant); Community only has "Invoicing". We look for the
        root that holds the standard "Accounting" entries submenu, preferring
        the Enterprise app, and insert our menu just before "Reporting".
        """
        menu = self.env.ref('auto_payment_matching.menu_auto_payment_matching', raise_if_not_found=False)
        if not menu:
            return
        root = self.search([('parent_id', '=', False), ('web_icon', '=like', 'account_accountant,%')], limit=1)
        if not root:
            entries = self.env.ref('account.menu_finance_entries', raise_if_not_found=False)
            root = entries.parent_id if entries else self.env.ref('account.menu_finance')
        reporting = self.search([('parent_id', '=', root.id), ('name', 'in', ('Reporting', 'Reports'))], limit=1)
        if not reporting:
            reporting = self.env.ref('account.menu_finance_reports', raise_if_not_found=False)
            if reporting and reporting.parent_id != root:
                reporting = self.browse()
        sequence = (reporting.sequence - 1) if reporting else 50
        menu.sudo().write({'parent_id': root.id, 'sequence': sequence})
