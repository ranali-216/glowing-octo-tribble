from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

PREFIX = 'auto_payment_matching.'


class ApmConfig:
    """Read-only view of the module settings (stored in ir.config_parameter).

    Settings are deliberately NOT stored on res.company: Odoo reads res.company
    on every request, so new columns there make the whole server return 500
    until the module is upgraded.
    """

    def __init__(self, env):
        icp = env['ir.config_parameter'].sudo()

        def get(key, default=False):
            return icp.get_param(PREFIX + key, default)

        def to_int(value, default):
            try:
                return int(value)
            except (TypeError, ValueError):
                return default

        def to_float(value):
            try:
                return float(value)
            except (TypeError, ValueError):
                return 0.0

        self.mode = get('mode', 'confident') or 'confident'
        self.auto_threshold = to_int(get('auto_threshold'), 90)
        self.suggest_threshold = to_int(get('suggest_threshold'), 40)
        self.writeoff_tolerance = to_float(get('writeoff_tolerance'))
        self.writeoff_account_id = env['account.account'].browse(to_int(get('writeoff_account_id'), 0)).exists()
        self.writeoff_journal_id = env['account.journal'].browse(to_int(get('writeoff_journal_id'), 0)).exists()
        # Booleans: a missing parameter means False (that is how Odoo stores an
        # unticked box). Defaults that should be True are seeded in data/.
        self.include_misc_entries = bool(get('include_misc_entries'))
        self.partner_fifo = bool(get('partner_fifo'))
        self.cron_auto_apply = bool(get('cron_auto_apply'))
        self.learn_partners = bool(get('learn_partners'))
        # v5.3
        self.payment_window_days = to_int(get('payment_window_days'), 45)
        self.use_rules = bool(get('use_rules'))

    @property
    def writeoff_enabled(self):
        return bool(self.writeoff_account_id and self.writeoff_tolerance > 0)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    apm_mode = fields.Selection(
        [
            ('suggest', 'Suggest only (a user always confirms)'),
            ('confident', 'Auto-reconcile confident matches'),
        ],
        string='Auto Matching Mode', default='confident',
        config_parameter=PREFIX + 'mode')
    apm_auto_threshold = fields.Integer(
        string='Auto-Reconcile Confidence (%)', default=90,
        config_parameter=PREFIX + 'auto_threshold')
    apm_suggest_threshold = fields.Integer(
        string='Suggestion Confidence (%)', default=40,
        config_parameter=PREFIX + 'suggest_threshold')
    apm_writeoff_account_id = fields.Many2one(
        'account.account', string='Payment Difference Account',
        config_parameter=PREFIX + 'writeoff_account_id')
    apm_writeoff_journal_id = fields.Many2one(
        'account.journal', string='Write-off Journal',
        config_parameter=PREFIX + 'writeoff_journal_id')
    apm_writeoff_tolerance = fields.Float(
        string='Write-off Tolerance (amount)',
        config_parameter=PREFIX + 'writeoff_tolerance')
    apm_include_misc_entries = fields.Boolean(
        string='Match Journal Entries Too',
        config_parameter=PREFIX + 'include_misc_entries')
    apm_partner_fifo = fields.Boolean(
        string='Suggest Oldest-First Allocation',
        config_parameter=PREFIX + 'partner_fifo')
    apm_cron_auto_apply = fields.Boolean(
        string='Scheduled Run May Reconcile',
        config_parameter=PREFIX + 'cron_auto_apply')
    apm_payment_window_days = fields.Integer(
        string='Usual Payment Window (days)', default=45,
        config_parameter=PREFIX + 'payment_window_days',
        help='A payment within this many days after the invoice date adds confidence.')
    apm_use_rules = fields.Boolean(
        string='Apply Matching Rules',
        config_parameter=PREFIX + 'use_rules',
        help='Off by default. When on, Matching Rules (book to an account, set a partner, exclude) '
             'run before invoice matching.')
    apm_learn_partners = fields.Boolean(
        string='Learn Partners from Manual Matches',
        config_parameter=PREFIX + 'learn_partners')

    def set_values(self):
        for rec in self:
            for value in (rec.apm_auto_threshold, rec.apm_suggest_threshold):
                if value < 0 or value > 100:
                    raise ValidationError(_('Confidence thresholds must be between 0 and 100.'))
            if rec.apm_suggest_threshold > rec.apm_auto_threshold:
                raise ValidationError(_(
                    'The suggestion threshold cannot be higher than the auto-reconcile threshold.'))
            if rec.apm_payment_window_days < 0:
                raise ValidationError(_('The payment window cannot be negative.'))
            if rec.apm_writeoff_tolerance < 0:
                raise ValidationError(_('The write-off tolerance cannot be negative.'))
        return super().set_values()

    @api.model
    def _apm_config(self):
        return ApmConfig(self.env)
