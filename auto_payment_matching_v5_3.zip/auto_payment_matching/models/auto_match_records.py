import re

from odoo import api, fields, models, _
from odoo.exceptions import UserError


STRATEGIES = [
    ('reference', 'Reference found in bank text'),
    ('reference_subset', 'Reference + amount combination'),
    ('partner_exact', 'Partner + exact amount'),
    ('partner_combination', 'Partner + invoice combination'),
    ('partner_fifo', 'Partner, oldest documents first'),
    ('global_exact', 'Unique open amount'),
]

AMOUNT_KINDS = [
    ('exact', 'Exact amount'),
    ('tolerance', 'Within write-off tolerance'),
    ('partial', 'Partial payment'),
    ('overpayment', 'Overpayment (credit stays open)'),
]


class AutoMatchSuggestion(models.Model):
    _name = 'auto.match.suggestion'
    _description = 'Auto Payment Matching Suggestion'
    _order = 'score desc, id desc'

    statement_line_id = fields.Many2one(
        'account.bank.statement.line', required=True, ondelete='cascade', index=True,
        string='Bank Transaction')
    company_id = fields.Many2one(related='statement_line_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='statement_line_id.currency_id')
    date = fields.Date(related='statement_line_id.date', store=True)
    payment_ref = fields.Char(related='statement_line_id.payment_ref', string='Bank Label')
    statement_amount = fields.Monetary(related='statement_line_id.amount', string='Bank Amount')
    partner_id = fields.Many2one('res.partner', string='Partner')
    move_line_ids = fields.Many2many(
        'account.move.line', 'auto_match_suggestion_aml_rel', 'suggestion_id', 'aml_id',
        string='Journal Items')
    move_ids = fields.Many2many('account.move', compute='_compute_move_ids', string='Documents')
    document_total = fields.Monetary(string='Documents Open Amount')
    difference = fields.Monetary(string='Difference')
    score = fields.Integer(string='Confidence (%)')
    confidence = fields.Selection(
        [('high', 'High'), ('medium', 'Medium'), ('low', 'Low')],
        compute='_compute_confidence', store=True)
    strategy = fields.Selection(STRATEGIES, string='How it was found')
    amount_kind = fields.Selection(AMOUNT_KINDS, string='Amount Result')
    reasons = fields.Text(string='Why')
    state = fields.Selection(
        [
            ('pending', 'To Review'),
            ('applied', 'Applied'),
            ('rejected', 'Rejected'),
            ('superseded', 'Superseded'),
            ('failed', 'Failed'),
            ('undone', 'Undone'),
        ],
        default='pending', required=True, index=True)
    message = fields.Text(readonly=True)

    @api.depends('move_line_ids')
    def _compute_move_ids(self):
        for rec in self:
            rec.move_ids = rec.move_line_ids.move_id

    @api.depends('score')
    def _compute_confidence(self):
        for rec in self:
            if rec.score >= 90:
                rec.confidence = 'high'
            elif rec.score >= 60:
                rec.confidence = 'medium'
            else:
                rec.confidence = 'low'

    def _apply(self, source='suggestion'):
        """Apply suggestions one by one. Returns (applied_count, failed_count)."""
        applied = failed = 0
        for rec in self:
            if rec.state != 'pending':
                continue
            ok, msg = rec.statement_line_id._apm_apply(
                rec.move_line_ids, source=source, suggestion=rec)
            if ok:
                applied += 1
                siblings = rec.statement_line_id.apm_suggestion_ids.filtered(
                    lambda s: s.state == 'pending' and s != rec)
                siblings.write({'state': 'superseded'})
            else:
                failed += 1
        return applied, failed

    def action_apply(self):
        applied, failed = self._apply()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Suggestions'),
                'message': _('%(ok)s applied, %(ko)s failed.', ok=applied, ko=failed),
                'type': 'warning' if failed else 'success',
                'sticky': False,
                'next': {'type': 'ir.actions.client', 'tag': 'soft_reload'},
            },
        }

    def action_reject(self):
        pending = self.filtered(lambda s: s.state == 'pending')
        pending.write({'state': 'rejected'})
        for st_line in pending.statement_line_id:
            if not st_line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending'):
                st_line._apm_set_result('partial' if st_line.apm_stage == 'partial' else 'not_found',
                                        _('All suggestions were rejected by %s.') % self.env.user.name)
        return True


class AutoMatchLog(models.Model):
    _name = 'auto.match.log'
    _description = 'Auto Payment Matching Activity Log'
    _order = 'id desc'

    statement_line_id = fields.Many2one(
        'account.bank.statement.line', ondelete='cascade', index=True, string='Bank Transaction')
    company_id = fields.Many2one(related='statement_line_id.company_id', store=True, index=True)
    currency_id = fields.Many2one(related='statement_line_id.currency_id')
    payment_ref = fields.Char(related='statement_line_id.payment_ref', string='Bank Label')
    user_id = fields.Many2one('res.users', default=lambda self: self.env.user, string='User')
    action = fields.Selection(
        [
            ('auto', 'Automatic'),
            ('suggestion', 'Suggestion Accepted'),
            ('manual', 'Manual'),
            ('rule', 'Matching Rule'),
            ('undo', 'Undo'),
        ],
        required=True)
    status = fields.Selection(
        [('success', 'Success'), ('partial', 'Partial'), ('failed', 'Failed'), ('info', 'Info')],
        required=True)
    score = fields.Integer(string='Confidence (%)')
    move_ids = fields.Many2many('account.move', 'auto_match_log_move_rel', 'log_id', 'move_id',
                                string='Documents')
    writeoff_move_ids = fields.Many2many('account.move', 'auto_match_log_writeoff_rel', 'log_id',
                                         'move_id', string='Write-offs')
    amount_applied = fields.Monetary(string='Applied')
    remaining_amount = fields.Monetary(string='Remaining After')
    message = fields.Text()

    # append-only: entries are written by the system (sudo); only administrators may change them
    def write(self, vals):
        if not self.env.su and not self.env.user.has_group('base.group_system'):
            raise UserError(_('The activity log cannot be changed.'))
        return super().write(vals)

    def unlink(self):
        if not self.env.su and not self.env.user.has_group('base.group_system'):
            raise UserError(_('The activity log cannot be deleted.'))
        return super().unlink()


class AutoMatchLearnedPartner(models.Model):
    _name = 'auto.match.learned.partner'
    _description = 'Partner Learned from Bank Data'
    _order = 'hits desc, id desc'

    key_type = fields.Selection(
        [('account_number', 'Bank Account Number'), ('partner_name', 'Payer Name')],
        required=True)
    key = fields.Char(required=True, index=True)
    partner_id = fields.Many2one('res.partner', required=True, ondelete='cascade')
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    hits = fields.Integer(default=1)
    last_used = fields.Datetime(default=fields.Datetime.now)

    _sql_constraints = [
        ('key_uniq', 'unique(key_type, key, company_id)', 'This key is already learned.'),
    ]

    @api.model
    def _apm_key(self, key_type, value):
        if not value:
            return False
        if key_type == 'account_number':
            return re.sub(r'\W+', '', value).upper() or False
        return ' '.join(value.lower().split()) or False

    @api.model
    def _apm_lookup(self, key_type, value, company):
        key = self._apm_key(key_type, value)
        if not key:
            return self.env['res.partner']
        rec = self.search([('key_type', '=', key_type), ('key', '=', key),
                           ('company_id', '=', company.id)], limit=1)
        return rec.partner_id

    @api.model
    def _apm_learn(self, st_line, partner):
        if not partner or not self.env['res.config.settings']._apm_config().learn_partners:
            return
        for key_type, value in (('account_number', st_line.account_number),
                                ('partner_name', st_line.partner_name)):
            key = self._apm_key(key_type, value)
            if not key:
                continue
            rec = self.search([('key_type', '=', key_type), ('key', '=', key),
                               ('company_id', '=', st_line.company_id.id)], limit=1)
            if rec:
                vals = {'last_used': fields.Datetime.now()}
                if rec.partner_id == partner:
                    vals['hits'] = rec.hits + 1
                else:
                    vals.update(partner_id=partner.id, hits=1)
                rec.write(vals)
            else:
                self.create({'key_type': key_type, 'key': key, 'partner_id': partner.id,
                             'company_id': st_line.company_id.id})
