import re

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class AutoMatchRule(models.Model):
    _name = 'auto.match.rule'
    _description = 'Auto Payment Matching Rule'
    _order = 'sequence, id'

    name = fields.Char(required=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, required=True)

    # -- conditions --------------------------------------------------------
    journal_ids = fields.Many2many(
        'account.journal', 'auto_match_rule_journal_rel', 'rule_id', 'journal_id',
        string='Bank Journals', domain="[('type', 'in', ('bank', 'cash')), ('company_id', '=', company_id)]",
        help='Leave empty for all bank and cash journals.')
    direction = fields.Selection(
        [('both', 'Money in and out'), ('inbound', 'Money in'), ('outbound', 'Money out')],
        default='both', required=True)
    label_match = fields.Selection(
        [('contains', 'Contains'), ('starts', 'Starts with'), ('regex', 'Regular expression')],
        string='Label Condition', default='contains', required=True)
    label_pattern = fields.Char(
        string='Label Text',
        help='Compared with the bank label, reference and notes (not case sensitive). '
             'For "Contains", separate alternatives with | (e.g. BANK CHARGES|SMS FEE).')
    amount_min = fields.Float(string='Amount From', help='0 = no minimum')
    amount_max = fields.Float(string='Amount To', help='0 = no maximum')

    # -- outcome -------------------------------------------------------------
    action = fields.Selection(
        [
            ('book', 'Book to an account'),
            ('partner', 'Set the partner, then match invoices'),
            ('exclude', 'Exclude from matching'),
        ],
        default='book', required=True)
    account_id = fields.Many2one(
        'account.account', string='Account',
        domain="[('deprecated', '=', False), ('company_id', '=', company_id)]")
    partner_id = fields.Many2one('res.partner', string='Partner')
    label = fields.Char(string='Journal Item Label', help='Optional text for the booked journal item.')
    auto_apply = fields.Boolean(
        string='Apply Without Asking', default=True,
        help='If unticked, the rule only proposes the booking and a user confirms it.')

    # -- statistics ------------------------------------------------------------
    match_count = fields.Integer(string='Times Used', readonly=True, copy=False)
    last_match_date = fields.Datetime(string='Last Used', readonly=True, copy=False)

    @api.constrains('label_match', 'label_pattern')
    def _check_regex(self):
        for rule in self:
            if rule.label_match == 'regex' and rule.label_pattern:
                try:
                    re.compile(rule.label_pattern)
                except re.error as exc:
                    raise ValidationError(_('Invalid regular expression in rule "%(rule)s": %(err)s',
                                            rule=rule.name, err=exc))

    @api.constrains('action', 'account_id', 'partner_id')
    def _check_outcome(self):
        for rule in self:
            if rule.action == 'book' and not rule.account_id:
                raise ValidationError(_('Rule "%s" books to an account: choose the account.') % rule.name)
            if rule.action == 'partner' and not rule.partner_id:
                raise ValidationError(_('Rule "%s" sets a partner: choose the partner.') % rule.name)

    @api.constrains('amount_min', 'amount_max')
    def _check_amounts(self):
        for rule in self:
            if rule.amount_min < 0 or rule.amount_max < 0:
                raise ValidationError(_('Amounts in rules are absolute values and cannot be negative.'))
            if rule.amount_max and rule.amount_min > rule.amount_max:
                raise ValidationError(_('"Amount From" is higher than "Amount To" in rule "%s".') % rule.name)

    # ------------------------------------------------------------------
    def _apm_matches(self, st_line):
        self.ensure_one()
        if self.company_id != st_line.company_id:
            return False
        if self.journal_ids and st_line.journal_id not in self.journal_ids:
            return False
        if self.direction == 'inbound' and st_line.amount < 0:
            return False
        if self.direction == 'outbound' and st_line.amount > 0:
            return False
        amount = abs(st_line.amount)
        if self.amount_min and amount < self.amount_min:
            return False
        if self.amount_max and amount > self.amount_max:
            return False
        if self.label_pattern:
            text = (st_line._apm_text() or '').lower()
            pattern = self.label_pattern.strip()
            if self.label_match == 'regex':
                try:
                    if not re.search(pattern, text, re.IGNORECASE):
                        return False
                except re.error:
                    return False
            elif self.label_match == 'starts':
                if not (st_line.payment_ref or '').lower().strip().startswith(pattern.lower()):
                    return False
            else:
                options = [p.strip().lower() for p in pattern.split('|') if p.strip()]
                if not any(opt in text for opt in options):
                    return False
        return True

    @api.model
    def _apm_find(self, st_line):
        for rule in self.search([('company_id', '=', st_line.company_id.id)]):
            if rule._apm_matches(st_line):
                return rule
        return self.browse()

    def _apm_hit(self):
        for rule in self.sudo():
            rule.write({'match_count': rule.match_count + 1, 'last_match_date': fields.Datetime.now()})

    def action_test_rule(self):
        """Show which open transactions this rule would catch."""
        self.ensure_one()
        lines = self.env['account.bank.statement.line'].search([
            ('company_id', '=', self.company_id.id),
            ('auto_payment_available', '=', True),
        ], limit=2000)
        hits = lines.filtered(self._apm_matches)
        action = self.env['ir.actions.act_window']._for_xml_id(
            'auto_payment_matching.action_auto_payment_matching_statement_lines')
        action.update({
            'name': _('Open transactions caught by "%s"') % self.name,
            'domain': [('id', 'in', hits.ids)],
            'context': {},
        })
        return action
