from odoo import api, fields, models, _
from odoo.exceptions import AccessError, UserError
from odoo.osv import expression
from odoo.tools.misc import format_date, format_datetime, formatLang

# Customer invoices only (no vendor bills anywhere in this module).
INVOICE_TYPES = ('out_invoice',)
RECEIVABLE = 'asset_receivable'

ST_ORDERS = {
    'date desc': 'date desc, id desc',
    'date asc': 'date asc, id asc',
    'amount desc': 'amount desc, id desc',
    'amount asc': 'amount asc, id asc',
}
INV_ORDERS = {
    'date desc': 'invoice_date desc, id desc',
    'date asc': 'invoice_date asc, id asc',
    'amount desc': 'amount_total_signed desc, id desc',
    'amount asc': 'amount_total_signed asc, id asc',
}


class AutoMatchWorkspace(models.AbstractModel):
    """Server side of the Payment Matching workspace (OWL client action)."""
    _name = 'auto.match.workspace'
    _description = 'Payment Matching Workspace'

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    @api.model
    def _check_access(self):
        """Every workspace entry point is for accountants only."""
        if not self.env.user.has_group('account.group_account_user'):
            raise AccessError(_('Payment Matching is available to accountants only.'))

    @api.model
    def _money(self, amount, currency):
        return formatLang(self.env, amount or 0.0, currency_obj=currency)

    @api.model
    def _st_base(self):
        # money received only
        return [('company_id', 'in', self.env.companies.ids), ('amount', '>', 0)]

    @api.model
    def _st_open(self):
        return self._st_base() + [('auto_payment_available', '=', True), ('apm_exclude', '=', False)]

    @api.model
    def _paging(self, params):
        offset = max(0, int(params.get('offset') or 0))
        limit = min(100, max(1, int(params.get('limit') or 25)))
        return offset, limit

    @api.model
    def _st_search_domain(self, search):
        if not search:
            return []
        return expression.OR([
            [('payment_ref', 'ilike', search)],
            [('partner_id', 'ilike', search)],
            [('partner_name', 'ilike', search)],
            [('auto_match_document_ids.name', 'ilike', search)],
        ])

    @api.model
    def _documents_of(self, st_line):
        return self.env['auto.match.excel.report']._matched_documents(st_line)

    @api.model
    def _st_row(self, line):
        currency = line.currency_id
        documents = self._documents_of(line) if line.auto_match_applied_amount else line.auto_match_document_ids
        return {
            'id': line.id,
            'date': format_date(self.env, line.date),
            'label': line.payment_ref or '',
            'partner': line.partner_id.display_name or line.partner_name or (
                _('%s (suggested)') % line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1].partner_id.display_name
                if line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1].partner_id else ''),
            'journal': line.journal_id.name or '',
            'inbound': line.amount >= 0,
            'amount': self._money(line.amount, currency),
            'to_allocate': self._money(line.auto_match_remaining_amount, currency),
            'applied': self._money(line.auto_match_applied_amount, currency),
            'remaining': self._money(line.auto_match_remaining_amount, currency),
            'stage': line.apm_stage,
            'last_run': format_datetime(self.env, line.auto_match_date) if line.auto_match_date else '',
            'documents': [{'id': m.id, 'name': m.name} for m in documents[:4]],
            'more_documents': max(0, len(documents) - 4),
            'message': line.auto_match_message or '',
            'has_suggestion': bool(line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')),
            'duplicate': bool(line.apm_duplicate_id),
            'can_undo': bool(line.auto_match_applied_amount),
        }

    # ------------------------------------------------------------------
    # sidebar
    # ------------------------------------------------------------------
    @api.model
    def get_counts(self):
        self._check_access()
        Move = self.env['account.move']
        return {
            'invoices': Move.search_count(self._invoice_domain({'stage': 'open'})),
            'bank': self.env['account.bank.statement.line'].search_count(self._st_open()),
            'review': self.env['auto.match.suggestion'].search_count([
                ('company_id', 'in', self.env.companies.ids), ('state', '=', 'pending'),
                ('statement_line_id.amount', '>', 0)]),
            'form_view_id': self.env.ref(
                'auto_payment_matching.view_auto_payment_matching_statement_line_form').id,
        }

    # ------------------------------------------------------------------
    # Transactions to reconcile: customer invoices
    # ------------------------------------------------------------------
    @api.model
    def _invoice_domain(self, params):
        domain = [
            ('company_id', 'in', self.env.companies.ids),
            ('state', '=', 'posted'),
            ('move_type', 'in', INVOICE_TYPES),
        ]
        stage = params.get('stage') or 'open'
        if stage == 'open':
            domain.append(('payment_state', 'in', ('not_paid', 'partial')))
        elif stage == 'ready':
            # open invoices whose customer already has an unmatched receipt
            partner_ids = [pid for pid, count in self._open_payment_counts().items() if pid and count]
            domain += [('payment_state', 'in', ('not_paid', 'partial')),
                       ('commercial_partner_id', 'in', partner_ids)]
        elif stage == 'pending':
            domain.append(('payment_state', '=', 'not_paid'))
        elif stage == 'partial':
            domain.append(('payment_state', '=', 'partial'))
        elif stage == 'full':
            domain.append(('payment_state', 'in', ('paid', 'in_payment')))
        search = params.get('search')
        if search:
            domain += expression.OR([
                [('name', 'ilike', search)],
                [('partner_id', 'ilike', search)],
                [('ref', 'ilike', search)],
                [('payment_reference', 'ilike', search)],
            ])
        return domain

    @api.model
    def _invoice_stage(self, move):
        if move.payment_state in ('paid', 'in_payment'):
            return 'full'
        if move.payment_state == 'partial':
            return 'partial'
        return 'pending'

    @api.model
    def _open_payment_counts(self):
        """{commercial_partner_id or 0: count} of open customer receipts."""
        counts = {}
        Line = self.env['account.bank.statement.line']
        for partner, count in Line._read_group(self._st_open(), ['partner_id'], ['__count']):
            key = partner.commercial_partner_id.id if partner else 0
            counts[key] = counts.get(key, 0) + count
        return counts

    @api.model
    def get_invoices(self, params):
        self._check_access()
        params = params or {}
        Move = self.env['account.move']
        offset, limit = self._paging(params)
        domain = self._invoice_domain(params)
        order = INV_ORDERS.get(params.get('order'), INV_ORDERS['date desc'])
        moves = Move.search(domain, order=order, offset=offset, limit=limit)
        counts = self._open_payment_counts()

        rows = []
        for move in moves:
            partner_count = counts.get(move.commercial_partner_id.id, 0)
            unassigned = counts.get(0, 0)
            stage = self._invoice_stage(move)
            rows.append({
                'id': move.id,
                'name': move.name,
                'type': dict(move._fields['move_type']._description_selection(self.env)).get(move.move_type),
                'date': format_date(self.env, move.invoice_date or move.date),
                'due': format_date(self.env, move.invoice_date_due) if move.invoice_date_due else '',
                'overdue': bool(move.invoice_date_due and move.invoice_date_due < fields.Date.context_today(self)
                                and stage != 'full'),
                'partner': move.partner_id.display_name or '',
                'total': self._money(move.amount_total, move.currency_id),
                'open': self._money(move.amount_residual, move.currency_id),
                'stage': stage,
                'partner_payments': partner_count,
                'unassigned_payments': unassigned,
                'can_reconcile': stage != 'full' and (partner_count + unassigned) > 0,
            })

        # KPI cards
        currency = self.env.company.currency_id
        all_open = Move.search(self._invoice_domain(dict(params, stage='open')))
        pending = all_open.filtered(lambda m: m.payment_state == 'not_paid')
        partial = all_open - pending
        ready = all_open.filtered(lambda m: counts.get(m.commercial_partner_id.id, 0))
        return {
            'rows': rows,
            'total': Move.search_count(domain),
            'kpis': [
                {'key': 'open', 'label': _('Open Invoices'), 'icon': 'fa-file-text-o',
                 'value': self._money(sum(abs(v) for v in all_open.mapped('amount_residual_signed')), currency),
                 'count': len(all_open)},
                {'key': 'pending', 'label': _('Pending'), 'icon': 'fa-hourglass-half',
                 'value': self._money(sum(abs(v) for v in pending.mapped('amount_residual_signed')), currency),
                 'count': len(pending)},
                {'key': 'partial', 'label': _('Partially Reconciled'), 'icon': 'fa-adjust',
                 'value': self._money(sum(abs(v) for v in partial.mapped('amount_residual_signed')), currency),
                 'count': len(partial)},
                {'key': 'ready', 'label': _('Payment Received'), 'icon': 'fa-bank',
                 'value': self._money(sum(abs(v) for v in ready.mapped('amount_residual_signed')), currency),
                 'count': len(ready)},
            ],
        }

    @api.model
    def _invoice_open_lines(self, move):
        return move.line_ids.filtered(
            lambda l: l.account_id.account_type == RECEIVABLE and not l.reconciled)

    @api.model
    def get_invoice_payments(self, invoice_id):
        """Open customer receipts that can pay this invoice: the customer's first,
        then receipts without a partner."""
        self._check_access()
        move = self.env['account.move'].browse(int(invoice_id)).exists()
        if not move:
            raise UserError(_('This invoice no longer exists.'))
        if move.move_type not in INVOICE_TYPES:
            raise UserError(_('Only customer invoices can be reconciled here.'))
        base = self._st_open()
        Line = self.env['account.bank.statement.line']
        partner_lines = Line.search(
            base + [('partner_id', 'child_of', move.commercial_partner_id.id)], order='date desc, id desc', limit=50)
        unassigned = Line.search(base + [('partner_id', '=', False)], order='date desc, id desc', limit=50)
        rows = []
        for line, own in [(l, True) for l in partner_lines] + [(l, False) for l in unassigned]:
            rows.append({
                'id': line.id,
                'date': format_date(self.env, line.date),
                'label': line.payment_ref or '',
                'partner': line.partner_id.display_name or line.partner_name or _('No partner'),
                'amount': self._money(line.amount, line.currency_id),
                'to_allocate': self._money(line.auto_match_remaining_amount, line.currency_id),
                'own': own,
                'stage': line.apm_stage,
            })
        return {
            'invoice': {
                'id': move.id,
                'name': move.name,
                'partner': move.partner_id.display_name,
                'open': self._money(move.amount_residual, move.currency_id),
                'total': self._money(move.amount_total, move.currency_id),
            },
            'payments': rows,
        }

    @api.model
    def reconcile_invoice(self, invoice_id, st_line_id, mode):
        """mode 'partial': this invoice only. mode 'auto': this invoice first,
        then the customer's oldest open documents until the payment is used."""
        self._check_access()
        move = self.env['account.move'].browse(int(invoice_id)).exists()
        st_line = self.env['account.bank.statement.line'].browse(int(st_line_id)).exists()
        if not move or not st_line:
            raise UserError(_('The invoice or the bank transaction no longer exists.'))
        inv_lines = self._invoice_open_lines(move)
        if not inv_lines:
            raise UserError(_('%s is already fully paid.') % move.name)
        amls = inv_lines
        if mode == 'auto':
            others = self.env['account.move.line'].search(
                st_line._apm_base_aml_domain() + [
                    ('partner_id', 'child_of', move.commercial_partner_id.id),
                    ('account_id', 'in', inv_lines.account_id.ids),
                    ('id', 'not in', inv_lines.ids),
                ], order='date_maturity asc, date asc, id asc', limit=200)
            sign = 1 if sum(inv_lines.mapped('amount_residual_currency')) > 0 else -1
            amls = inv_lines | others.filtered(lambda l: l.amount_residual_currency * sign > 0)
        ok, message = st_line._apm_apply(amls, source='manual', keep_order=True)
        return {'ok': ok, 'message': message}

    @api.model
    def open_manual(self, st_line_id, invoice_id=False):
        self._check_access()
        st_line = self.env['account.bank.statement.line'].browse(int(st_line_id)).exists()
        if not st_line:
            raise UserError(_('This bank transaction no longer exists.'))
        action = st_line.action_apm_open_manual()
        ctx = dict(action.get('context') or {})
        if invoice_id:
            move = self.env['account.move'].browse(int(invoice_id))
            ctx['default_partner_id'] = move.commercial_partner_id.id
            ctx['apm_preselect_aml_ids'] = self._invoice_open_lines(move).ids
        action['context'] = ctx
        return action

    # ------------------------------------------------------------------
    # Transactions to reconcile: bank side
    # ------------------------------------------------------------------
    @api.model
    def get_bank_open(self, params):
        self._check_access()
        params = params or {}
        Line = self.env['account.bank.statement.line']
        offset, limit = self._paging(params)
        domain = self._st_open() + self._st_search_domain(params.get('search'))
        stage = params.get('stage') or 'all'
        if stage in ('pending', 'partial'):
            domain.append(('apm_stage', '=', stage))
        order = ST_ORDERS.get(params.get('order'), ST_ORDERS['date desc'])
        lines = Line.search(domain, order=order, offset=offset, limit=limit)
        return {'rows': [self._st_row(l) for l in lines], 'total': Line.search_count(domain), 'kpis': []}

    @api.model
    def bank_action(self, st_line_id, action):
        self._check_access()
        line = self.env['account.bank.statement.line'].browse(int(st_line_id)).exists()
        if not line:
            raise UserError(_('This bank transaction no longer exists.'))
        if action == 'auto':
            line._apm_run(allow_apply=True)
            ok = line.auto_match_status != 'error'
            return {'ok': ok, 'message': line.auto_match_message or _('Done.')}
        if action == 'undo':
            line.action_apm_undo()
            return {'ok': True, 'message': _('Reconciliation undone.')}
        raise UserError(_('Unknown action.'))

    # ------------------------------------------------------------------
    # Transaction records
    # ------------------------------------------------------------------
    @api.model
    def get_records(self, params):
        self._check_access()
        params = params or {}
        Line = self.env['account.bank.statement.line']
        offset, limit = self._paging(params)
        base = self._st_base() + [('apm_stage', 'in', ('partial', 'full'))]
        domain = base + self._st_search_domain(params.get('search'))
        stage = params.get('stage') or 'all'
        if stage in ('partial', 'full'):
            domain.append(('apm_stage', '=', stage))
        elif stage == 'remaining':
            domain += [('apm_stage', '=', 'partial'), ('auto_match_remaining_amount', '>', 0)]
        order = ST_ORDERS.get(params.get('order'), ST_ORDERS['date desc'])
        lines = Line.search(domain, order=order, offset=offset, limit=limit)

        currency = self.env.company.currency_id
        kpi = {}
        for stg, amount, remaining, count in Line._read_group(
                base, ['apm_stage'],
                ['auto_match_payment_amount:sum', 'auto_match_remaining_amount:sum', '__count']):
            kpi[stg] = (amount or 0.0, remaining or 0.0, count)
        full = kpi.get('full', (0.0, 0.0, 0))
        part = kpi.get('partial', (0.0, 0.0, 0))
        return {
            'rows': [self._st_row(l) for l in lines],
            'total': Line.search_count(domain),
            'kpis': [
                {'key': 'total', 'label': _('Total Payments'), 'icon': 'fa-credit-card',
                 'value': self._money(full[0] + part[0], currency), 'count': full[2] + part[2]},
                {'key': 'full', 'label': _('Fully Reconciled'), 'icon': 'fa-check',
                 'value': self._money(full[0], currency), 'count': full[2]},
                {'key': 'partial', 'label': _('Partially Reconciled'), 'icon': 'fa-clock-o',
                 'value': self._money(part[0], currency), 'count': part[2]},
                {'key': 'remaining', 'label': _('Remaining Amount'), 'icon': 'fa-hourglass-half',
                 'value': self._money(part[1], currency), 'count': part[2]},
            ],
        }

    # ------------------------------------------------------------------
    # Review
    # ------------------------------------------------------------------
    @api.model
    def get_review(self, params):
        self._check_access()
        params = params or {}
        Suggestion = self.env['auto.match.suggestion']
        offset, limit = self._paging(params)
        domain = [('company_id', 'in', self.env.companies.ids), ('state', '=', 'pending'),
                  ('statement_line_id.amount', '>', 0)]
        search = params.get('search')
        if search:
            domain += expression.OR([
                [('statement_line_id.payment_ref', 'ilike', search)],
                [('partner_id', 'ilike', search)],
                [('move_line_ids.move_id.name', 'ilike', search)],
            ])
        records = Suggestion.search(domain, order='date desc, score desc, id desc', offset=offset, limit=limit)
        quality = {'high': _('Strong match'), 'medium': _('Likely match'), 'low': _('Possible match')}
        rows = []
        for sug in records:
            line = sug.statement_line_id
            rows.append({
                'id': sug.id,
                'st_line_id': line.id,
                'date': format_date(self.env, line.date),
                'label': line.payment_ref or '',
                'partner': sug.partner_id.display_name or line.partner_name or '',
                'amount': self._money(line.amount, line.currency_id),
                'documents': [{'id': m.id, 'name': m.name} for m in sug.move_ids],
                'documents_total': self._money(sug.document_total, line.currency_id),
                'quality': sug.confidence,
                'quality_label': quality.get(sug.confidence, ''),
                'reasons': [r.lstrip('- ').strip() for r in (sug.reasons or '').splitlines() if r.strip()],
            })
        return {'rows': rows, 'total': Suggestion.search_count(domain), 'kpis': []}

    @api.model
    def review_action(self, suggestion_id, action):
        self._check_access()
        sug = self.env['auto.match.suggestion'].browse(int(suggestion_id)).exists()
        if not sug or sug.state != 'pending':
            raise UserError(_('This suggestion is no longer pending.'))
        if action == 'apply':
            applied, _failed = sug._apply()
            sug.invalidate_recordset()
            return {'ok': bool(applied), 'message': sug.message or ''}
        sug.action_reject()
        return {'ok': True, 'message': _('Suggestion rejected.')}

    # ------------------------------------------------------------------
    # Excel
    # ------------------------------------------------------------------
    @api.model
    def excel_report(self, params):
        """Create the workbook and return its download URL."""
        self._check_access()
        params = params or {}
        vals = {
            'period_type': 'date' if params.get('period_type') == 'date' else 'month',
            'status': params.get('status') if params.get('status') in (
                'all', 'full', 'partial', 'review', 'pending') else 'all',
        }
        if vals['period_type'] == 'month':
            vals['months'] = ','.join(params.get('months') or [])
        else:
            vals['date_from'] = params.get('date_from') or False
            vals['date_to'] = params.get('date_to') or False
        wizard = self.env['auto.match.excel.report'].create(vals)
        url, name = wizard._create_attachment()
        return {'url': url, 'name': name}

    @api.model
    def excel_defaults(self):
        self._check_access()
        today = fields.Date.context_today(self)
        return {
            'date_from': fields.Date.to_string(today.replace(day=1)),
            'date_to': fields.Date.to_string(today),
            'year': today.year,
            'month_key': today.strftime('%Y-%m'),
        }
