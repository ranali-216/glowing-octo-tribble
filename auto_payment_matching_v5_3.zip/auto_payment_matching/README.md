# Auto Payment Matching v5 (Odoo 17)

Customer side only: money received + customer invoices. Vendor bills and outgoing payments are never touched.

Accounting app top bar > **Payment Matching** opens a workspace with four pages:
Transactions to Reconcile (Customer Invoices tab with a Reconcile button, Customer Receipts tab),
Transaction Records, Review Transactions, Excel Report.

Stages: Pending / Partially Reconciled / Fully Reconciled.

Reconcile dialog on an invoice:
* Auto Match: this invoice first, then the partner's oldest open documents.
* Partial Match: this invoice only.
* Match Manually: all of the partner's open documents, this invoice pre-ticked.

Tests:
odoo-bin -c odoo.conf -d test_db -i auto_payment_matching --test-tags /auto_payment_matching --stop-after-init
