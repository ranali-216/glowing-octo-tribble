import base64
import calendar
import io
from datetime import date, timedelta

import xlsxwriter
from xlsxwriter.utility import xl_col_to_name

from odoo import api, fields, models, _
from odoo.exceptions import UserError

STATUS_ORDER = ('full', 'partial', 'review', 'pending')


class AutoMatchExcelReport(models.TransientModel):
    _name = 'auto.match.excel.report'
    _description = 'Bank Transactions - Excel Report'

    period_type = fields.Selection(
        [('month', 'Month wise'), ('date', 'Date wise')],
        string='Report By', default='month', required=True)
    months = fields.Char(
        string='Months', help='Comma separated YYYY-MM values, e.g. 2026-08,2026-09')
    date_from = fields.Date(
        string='From', default=lambda self: fields.Date.context_today(self).replace(day=1))
    date_to = fields.Date(string='To', default=fields.Date.context_today)
    status = fields.Selection(
        [
            ('all', 'All transactions'),
            ('full', 'Fully Reconciled'),
            ('partial', 'Partially Reconciled'),
            ('review', 'Needs Review'),
            ('pending', 'Pending'),
        ],
        string='Transactions', default='all', required=True)
    journal_ids = fields.Many2many(
        'account.journal', 'auto_match_excel_report_journal_rel', 'wizard_id', 'journal_id',
        string='Bank Journals', domain="[('type', 'in', ('bank', 'cash'))]",
        help='Leave empty for all bank and cash journals.')
    partner_id = fields.Many2one('res.partner', string='Partner')

    # ------------------------------------------------------------------
    # Period handling
    # ------------------------------------------------------------------
    def _month_keys(self):
        keys = []
        for raw in (self.months or '').split(','):
            raw = raw.strip()
            try:
                year, month = (int(x) for x in raw.split('-'))
                date(year, month, 1)
            except (ValueError, TypeError):
                continue
            if (year, month) not in keys:
                keys.append((year, month))
        return sorted(keys)

    def _ranges(self):
        """List of (start, end) dates covered by the report."""
        self.ensure_one()
        if self.period_type == 'month':
            keys = self._month_keys()
            if not keys:
                raise UserError(_('Select at least one month.'))
            return [(date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1])) for y, m in keys]
        if not self.date_from or not self.date_to:
            raise UserError(_('Choose both dates.'))
        if self.date_from > self.date_to:
            raise UserError(_('"From" must be before "To".'))
        return [(self.date_from, self.date_to)]

    def _period_label(self):
        ranges = self._ranges()
        if self.period_type == 'month':
            return ', '.join(start.strftime('%B %Y') for start, _end in ranges)
        start, end = ranges[0]
        return '%s to %s' % (start.strftime('%d-%m-%Y'), end.strftime('%d-%m-%Y'))

    # ------------------------------------------------------------------
    # Data
    # ------------------------------------------------------------------
    @api.model
    def _line_status(self, st_line):
        if st_line.apm_stage == 'full':
            return 'full'
        if st_line.apm_stage == 'partial':
            return 'partial'
        if st_line.auto_match_status == 'suggested' or st_line.apm_rule_id:
            return 'review'
        return 'pending'

    def _status_labels(self):
        return {
            'full': _('Fully Reconciled'),
            'partial': _('Partially Reconciled'),
            'review': _('Needs Review'),
            'pending': _('Pending'),
        }

    def _get_lines(self):
        self.ensure_one()
        period_domain = []
        for start, end in self._ranges():
            part = ['&', ('date', '>=', start), ('date', '<=', end)]
            period_domain = part if not period_domain else ['|'] + period_domain + part
        # customer receipts only (money in)
        domain = [('company_id', 'in', self.env.companies.ids), ('amount', '>', 0)] + period_domain
        if self.journal_ids:
            domain.append(('journal_id', 'in', self.journal_ids.ids))
        if self.partner_id:
            domain.append(('partner_id', 'child_of', self.partner_id.commercial_partner_id.id))
        lines = self.env['account.bank.statement.line'].search(domain, order='date asc, id asc')
        if self.status != 'all':
            lines = lines.filtered(lambda l: self._line_status(l) == self.status)
        return lines

    @api.model
    def _matched_documents(self, st_line):
        """Entries reconciled with this bank transaction, including those
        reconciled outside this module (bank reconciliation widget)."""
        own = st_line.move_id
        items = own.line_ids
        partials = items.matched_debit_ids | items.matched_credit_ids
        counterparts = (partials.debit_move_id | partials.credit_move_id).filtered(lambda l: l.move_id != own)
        documents = counterparts.move_id | st_line.auto_match_document_ids
        return documents - st_line.apm_writeoff_move_ids

    # ------------------------------------------------------------------
    # Workbook
    # ------------------------------------------------------------------
    def _build_workbook(self):
        self.ensure_one()
        lines = self._get_lines()
        labels = self._status_labels()
        company = self.env.company
        period_text = self._period_label()

        output = io.BytesIO()
        book = xlsxwriter.Workbook(output, {'in_memory': True})
        f = {
            'title': book.add_format({'bold': True, 'font_size': 14}),
            'sub': book.add_format({'italic': True, 'font_color': '#555555'}),
            'head': book.add_format({'bold': True, 'bg_color': '#12A37A', 'font_color': '#FFFFFF',
                                     'border': 1, 'text_wrap': True, 'valign': 'vcenter'}),
            'text': book.add_format({'border': 1, 'valign': 'top'}),
            'wrap': book.add_format({'border': 1, 'valign': 'top', 'text_wrap': True}),
            'date': book.add_format({'border': 1, 'valign': 'top', 'num_format': 'dd-mm-yyyy'}),
            'money': book.add_format({'border': 1, 'valign': 'top', 'num_format': '#,##0.00'}),
            'int': book.add_format({'border': 1, 'valign': 'top', 'num_format': '0'}),
            'total': book.add_format({'bold': True, 'top': 2, 'bottom': 1}),
            'total_money': book.add_format({'bold': True, 'top': 2, 'bottom': 1, 'num_format': '#,##0.00'}),
            'total_int': book.add_format({'bold': True, 'top': 2, 'bottom': 1, 'num_format': '0'}),
            'empty': book.add_format({'italic': True, 'font_color': '#888888'}),
            'full': book.add_format({'border': 1, 'valign': 'top', 'bg_color': '#DFF3EA'}),
            'partial': book.add_format({'border': 1, 'valign': 'top', 'bg_color': '#FCEBD3'}),
            'review': book.add_format({'border': 1, 'valign': 'top', 'bg_color': '#DCE9FB'}),
            'pending': book.add_format({'border': 1, 'valign': 'top', 'bg_color': '#ECEEF2'}),
        }
        header_row = 3

        def sheet_header(ws, title, headers):
            ws.write(0, 0, title, f['title'])
            ws.write(1, 0, _('Period: %(p)s. Transactions: %(s)s.',
                             p=period_text, s=dict(self._fields['status']._description_selection(self.env))[self.status]),
                     f['sub'])
            for col, (label, width) in enumerate(headers):
                ws.write(header_row, col, label, f['head'])
                ws.set_column(col, col, width)
            ws.set_row(header_row, 30)

        def write_date(ws, row, col, value):
            if value:
                ws.write_datetime(row, col, fields.Datetime.to_datetime(value), f['date'])
            else:
                ws.write(row, col, '', f['text'])

        # Collect per-line data once
        data = []
        for st_line in lines:
            status = self._line_status(st_line)
            documents = self._matched_documents(st_line) if st_line.auto_match_applied_amount else \
                self.env['account.move']
            proposed = st_line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1].move_ids
            if st_line.apm_rule_id and not proposed:
                proposed_text = _('Rule: %s') % st_line.apm_rule_id.name
            else:
                proposed_text = ', '.join(proposed.mapped('name'))
            if self.period_type == 'month':
                group_key = st_line.date.replace(day=1)
                group_label = st_line.date.strftime('%B %Y')
            else:
                group_key = st_line.date
                group_label = st_line.date.strftime('%d-%m-%Y')
            data.append({
                'line': st_line, 'status': status, 'documents': documents,
                'proposed': proposed_text, 'group_key': group_key, 'group_label': group_label,
            })

        # ---- Sheet 1: Summary (one row per month or per date) -----------
        ws = book.add_worksheet(_('Summary'))
        period_title = _('Month') if self.period_type == 'month' else _('Date')
        sheet_header(ws, _('Customer Receipts Summary - %s') % company.name, [
            (period_title, 18), (_('Transactions'), 13), (_('Bank Amount'), 16), (_('Reconciled Amount'), 17),
            (_('Remaining Amount'), 17), (labels['full'], 14), (labels['partial'], 15),
            (labels['review'], 13), (labels['pending'], 11),
        ])
        groups = {}
        for item in data:
            g = groups.setdefault(item['group_key'], {
                'label': item['group_label'], 'count': 0, 'amount': 0.0, 'applied': 0.0, 'remaining': 0.0,
                'full': 0, 'partial': 0, 'review': 0, 'pending': 0})
            line = item['line']
            g['count'] += 1
            g['amount'] += line.amount
            g['applied'] += line.auto_match_applied_amount
            g['remaining'] += line.auto_match_remaining_amount
            g[item['status']] += 1
        row = header_row + 1
        for key in sorted(groups):
            g = groups[key]
            ws.write(row, 0, g['label'], f['text'])
            ws.write_number(row, 1, g['count'], f['int'])
            ws.write_number(row, 2, g['amount'], f['money'])
            ws.write_number(row, 3, g['applied'], f['money'])
            ws.write_number(row, 4, g['remaining'], f['money'])
            for col, status in enumerate(STATUS_ORDER, start=5):
                ws.write_number(row, col, g[status], f['int'])
            row += 1
        if groups:
            ws.write(row, 0, _('Total'), f['total'])
            for col in range(1, 9):
                letter = xl_col_to_name(col)
                fmt = f['total_money'] if col in (2, 3, 4) else f['total_int']
                ws.write_formula(row, col, '=SUM(%s%d:%s%d)' % (letter, header_row + 2, letter, row), fmt)
        else:
            ws.write(row, 0, _('No customer receipts in this period.'), f['empty'])
        ws.freeze_panes(header_row + 1, 1)

        # ---- Sheet 2: Transactions (one row per bank transaction) -----------
        ws = book.add_worksheet(_('Transactions'))
        headers = [
            (_('Date'), 12), (_('Month'), 15), (_('Journal'), 16), (_('Bank Label'), 36), (_('Partner'), 26),
            (_('Currency'), 9), (_('Bank Amount'), 15), (_('Reconciled Amount'), 16), (_('Remaining Amount'), 16),
            (_('Status'), 20), (_('Matched Invoices'), 32), (_('Invoices Still Open'), 30),
            (_('Proposed for Review'), 28), (_('Last Matched On'), 16), (_('Note'), 48),
        ]
        sheet_header(ws, _('Customer Receipts - %s') % company.name, headers)
        row = header_row + 1
        for item in data:
            line, status, documents = item['line'], item['status'], item['documents']
            still_open = documents.filtered(
                lambda m: m.is_invoice(include_receipts=True) and not m.currency_id.is_zero(m.amount_residual))
            write_date(ws, row, 0, line.date)
            ws.write(row, 1, line.date.strftime('%B %Y'), f['text'])
            ws.write(row, 2, line.journal_id.name or '', f['text'])
            ws.write(row, 3, line.payment_ref or '', f['wrap'])
            ws.write(row, 4, line.partner_id.display_name or line.partner_name or
                     ', '.join(documents.commercial_partner_id.mapped('display_name')), f['wrap'])
            ws.write(row, 5, line.currency_id.name or '', f['text'])
            ws.write_number(row, 6, line.amount, f['money'])
            ws.write_number(row, 7, line.auto_match_applied_amount, f['money'])
            ws.write_number(row, 8, line.auto_match_remaining_amount, f['money'])
            ws.write(row, 9, labels[status], f[status])
            ws.write(row, 10, ', '.join(documents.mapped('name')), f['wrap'])
            ws.write(row, 11, ', '.join('%s (%s)' % (m.name, '{:,.2f}'.format(m.amount_residual))
                                        for m in still_open), f['wrap'])
            ws.write(row, 12, item['proposed'], f['wrap'])
            write_date(ws, row, 13, line.auto_match_date)
            ws.write(row, 14, line.auto_match_message or '', f['wrap'])
            row += 1
        if data:
            ws.write(row, 5, _('Total'), f['total'])
            for col in (6, 7, 8):
                letter = xl_col_to_name(col)
                ws.write_formula(row, col, '=SUBTOTAL(9,%s%d:%s%d)' % (letter, header_row + 2, letter, row),
                                 f['total_money'])
            ws.autofilter(header_row, 0, row - 1, len(headers) - 1)
        else:
            ws.write(row, 0, _('No customer receipts in this period.'), f['empty'])
        ws.freeze_panes(header_row + 1, 4)

        # ---- Sheet 3: Matched documents ---------------------------------------
        ws = book.add_worksheet(_('Matched Invoices'))
        doc_headers = [
            (_('Bank Date'), 12), (_('Bank Label'), 32), (_('Bank Amount'), 15), (_('Status'), 20),
            (_('Invoice'), 20), (_('Type'), 16), (_('Partner'), 26), (_('Invoice Date'), 13),
            (_('Due Date'), 12), (_('Invoice Total'), 15), (_('Still Open'), 14), (_('Payment Status'), 16),
        ]
        sheet_header(ws, _('Customer invoices settled by receipts - %s') % company.name, doc_headers)
        move_types = dict(self.env['account.move']._fields['move_type']._description_selection(self.env))
        pay_states = dict(self.env['account.move']._fields['payment_state']._description_selection(self.env))
        row = header_row + 1
        for item in data:
            line = item['line']
            for doc in item['documents']:
                write_date(ws, row, 0, line.date)
                ws.write(row, 1, line.payment_ref or '', f['wrap'])
                ws.write_number(row, 2, line.amount, f['money'])
                ws.write(row, 3, labels[item['status']], f[item['status']])
                ws.write(row, 4, doc.name or '', f['text'])
                ws.write(row, 5, move_types.get(doc.move_type, doc.move_type), f['text'])
                ws.write(row, 6, doc.partner_id.display_name or '', f['wrap'])
                write_date(ws, row, 7, doc.invoice_date or doc.date)
                write_date(ws, row, 8, doc.invoice_date_due)
                ws.write_number(row, 9, doc.amount_total, f['money'])
                ws.write_number(row, 10, doc.amount_residual, f['money'])
                ws.write(row, 11, pay_states.get(doc.payment_state, '')
                         if doc.is_invoice(include_receipts=True) else '', f['text'])
                row += 1
        if row > header_row + 1:
            ws.autofilter(header_row, 0, row - 1, len(doc_headers) - 1)
        else:
            ws.write(row, 0, _('No invoices were settled in this period.'), f['empty'])
        ws.freeze_panes(header_row + 1, 0)

        book.close()
        return output.getvalue()

    def _file_name(self):
        ranges = self._ranges()
        start, end = ranges[0][0], ranges[-1][1]
        if self.period_type == 'month' and len(ranges) == 1:
            suffix = start.strftime('%Y_%m')
        else:
            suffix = '%s_%s' % (start.strftime('%Y%m%d'), end.strftime('%Y%m%d'))
        return 'Customer_Receipts_%s.xlsx' % suffix

    def _create_attachment(self):
        """Build the workbook and store it as an attachment; returns (url, name)."""
        self.ensure_one()
        # exports are throw-away files: remove this user's exports older than a day
        self.env['ir.attachment'].sudo().search([
            ('res_model', '=', self._name), ('create_uid', '=', self.env.uid),
            ('create_date', '<', fields.Datetime.now() - timedelta(days=1))]).unlink()
        content = self._build_workbook()
        name = self._file_name()
        attachment = self.env['ir.attachment'].create({
            'name': name,
            'datas': base64.b64encode(content),
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'res_model': self._name,
            'res_id': self.id,
        })
        return '/web/content/%s?download=true' % attachment.id, name

    def action_generate(self):
        url, _name = self._create_attachment()
        return {'type': 'ir.actions.act_url', 'url': url, 'target': 'self'}
