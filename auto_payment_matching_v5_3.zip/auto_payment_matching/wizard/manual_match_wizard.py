from odoo import api, fields, models, Command, _
from odoo.exceptions import UserError
from odoo.tools.misc import formatLang


class AutoMatchManualWizard(models.TransientModel):
    _name = 'auto.match.manual.wizard'
    _description = 'Manually Match a Bank Transaction'

    statement_line_id = fields.Many2one('account.bank.statement.line', required=True, readonly=True)
    company_id = fields.Many2one(related='statement_line_id.company_id')
    currency_id = fields.Many2one(related='statement_line_id.currency_id')
    payment_ref = fields.Char(related='statement_line_id.payment_ref')
    date = fields.Date(related='statement_line_id.date')
    amount = fields.Monetary(related='statement_line_id.amount', string='Bank Amount')
    direction = fields.Selection(related='statement_line_id.apm_direction')
    remaining_amount = fields.Monetary(compute='_compute_remaining', string='To Allocate')
    partner_id = fields.Many2one('res.partner', string='Customer')
    line_ids = fields.One2many('auto.match.manual.wizard.line', 'wizard_id', string='Open Invoices')
    selected_total = fields.Monetary(compute='_compute_totals', string='Selected')
    difference = fields.Monetary(compute='_compute_totals')
    result_hint = fields.Char(compute='_compute_totals')
    writeoff_available = fields.Boolean(compute='_compute_writeoff_available')
    apply_writeoff = fields.Boolean(
        string='Write off small difference',
        default=lambda self: self.env['res.config.settings']._apm_config().writeoff_enabled)

    @api.depends('statement_line_id')
    def _compute_remaining(self):
        for wiz in self:
            _lines, remaining = wiz.statement_line_id._apm_payment_state() if wiz.statement_line_id else (None, 0.0)
            wiz.remaining_amount = abs(remaining)

    @api.depends('company_id')
    def _compute_writeoff_available(self):
        enabled = self.env['res.config.settings']._apm_config().writeoff_enabled
        for wiz in self:
            wiz.writeoff_available = enabled

    @api.depends('line_ids.selected', 'line_ids.residual', 'remaining_amount')
    def _compute_totals(self):
        for wiz in self:
            sign = -1 if wiz.direction == 'outbound' else 1
            total = sum(l.residual for l in wiz.line_ids if l.selected) * sign
            wiz.selected_total = total
            wiz.difference = wiz.remaining_amount - total
            currency = wiz.currency_id
            if not currency or not any(wiz.line_ids.mapped('selected')):
                wiz.result_hint = _('Select the documents this payment settles.')
            elif currency.is_zero(wiz.difference):
                wiz.result_hint = _('Exact match: everything selected will be fully paid.')
            elif wiz.difference > 0:
                wiz.result_hint = _('%s of the payment stays unallocated (open credit on the partner).') % \
                    formatLang(self.env, wiz.difference, currency_obj=currency)
            else:
                wiz.result_hint = _('The last document in the list will stay open for %s.') % \
                    formatLang(self.env, -wiz.difference, currency_obj=currency)

    @api.model
    def default_get(self, fields_list):
        vals = super().default_get(fields_list)
        st_line = self.env['account.bank.statement.line'].browse(
            vals.get('statement_line_id') or self.env.context.get('active_id'))
        if st_line:
            vals['statement_line_id'] = st_line.id
            if 'partner_id' in fields_list and not vals.get('partner_id'):
                partner, _source = st_line._apm_resolve_partner()
                if not partner:
                    best = st_line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1]
                    partner = best.partner_id
                vals['partner_id'] = partner.id
        return vals

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        st_line = self.statement_line_id
        commands = [Command.clear()]
        if st_line and self.partner_id:
            forced = self.env.context.get('apm_preselect_aml_ids')
            if forced:
                preselect = self.env['account.move.line'].browse(forced)
            else:
                preselect = st_line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1].move_line_ids
            amls = self.env['account.move.line'].search(
                st_line._apm_base_aml_domain() + [('partner_id', 'child_of', self.partner_id.commercial_partner_id.id)],
                order='date_maturity asc, date asc, id asc', limit=200)
            for seq, aml in enumerate(amls, 1):
                commands.append(Command.create({
                    'sequence': seq * 10,
                    'move_line_id': aml.id,
                    'residual': st_line._apm_line_residual(aml),
                    'selected': aml in preselect,
                }))
        self.line_ids = commands

    def _reopen(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Match Payment'),
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }

    def action_select_oldest(self):
        """Tick documents oldest first until the payment is covered."""
        self.ensure_one()
        sign = -1 if self.direction == 'outbound' else 1
        self.line_ids.write({'selected': False})
        covered = 0.0
        for line in self.line_ids.sorted(lambda l: (l.date_maturity or l.date, l.id)):
            if self.currency_id.compare_amounts(covered, self.remaining_amount) >= 0:
                break
            if line.residual * sign > 0:
                line.selected = True
                covered += line.residual * sign
        return self._reopen()

    def action_clear(self):
        self.line_ids.write({'selected': False})
        return self._reopen()

    def action_apply(self):
        self.ensure_one()
        lines = self.line_ids.filtered('selected').sorted('sequence')
        if not lines:
            raise UserError(_('Select at least one document.'))
        ok, message = self.statement_line_id._apm_apply(
            lines.move_line_id,
            source='manual',
            writeoff=self.apply_writeoff and self.writeoff_available,
            keep_order=True,
        )
        if not ok:
            raise UserError(message)
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Payment matched'),
                'message': message,
                'type': 'success',
                'sticky': False,
                'next': {'type': 'ir.actions.act_window_close'},
            },
        }


class AutoMatchManualWizardLine(models.TransientModel):
    _name = 'auto.match.manual.wizard.line'
    _description = 'Manual Match Document Line'
    _order = 'sequence, id'

    wizard_id = fields.Many2one('auto.match.manual.wizard', required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    selected = fields.Boolean(string='Pay')
    move_line_id = fields.Many2one('account.move.line', required=True, readonly=True)
    move_id = fields.Many2one(related='move_line_id.move_id', string='Document')
    move_type = fields.Selection(related='move_line_id.move_id.move_type', string='Type')
    ref = fields.Char(related='move_line_id.move_id.ref', string='Reference')
    date = fields.Date(related='move_line_id.date')
    date_maturity = fields.Date(related='move_line_id.date_maturity', string='Due Date')
    account_id = fields.Many2one(related='move_line_id.account_id')
    currency_id = fields.Many2one(related='wizard_id.currency_id')
    residual = fields.Monetary(string='Open Amount (signed)', readonly=True)
    residual_display = fields.Monetary(compute='_compute_residual_display', string='Open Amount')
    effect = fields.Selection(
        [('settle', 'Settled by payment'), ('offset', 'Reduces amount (credit note)')],
        compute='_compute_residual_display')

    @api.depends('residual', 'wizard_id.direction')
    def _compute_residual_display(self):
        for line in self:
            sign = -1 if line.wizard_id.direction == 'outbound' else 1
            line.residual_display = abs(line.residual)
            line.effect = 'settle' if line.residual * sign >= 0 else 'offset'
