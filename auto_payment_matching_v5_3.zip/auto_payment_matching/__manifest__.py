{
    'name': 'Auto Payment Matching',
    'version': '17.0.5.3.0',
    'category': 'Accounting/Accounting',
    'summary': 'Match customer receipts with customer invoices: workspace, scoring, duplicate guard, Excel report',
    'description': """
Auto Payment Matching v3
========================
* Payment Matching workspace (Accounting top bar): Transactions to Reconcile
  (customer invoices with a Reconcile button + customer receipts), Transaction Records,
  Review Transactions, Excel Report. Stages: Pending / Partially / Fully Reconciled.
* Excel report of reconciled and partially reconciled transactions, with
  the documents each one settled.
* Scoring engine: document references, partner (bank account, payer name,
  learned mappings, rules), exact / combination / partial amounts.
* Matching rules: book bank charges and other invoice-less transactions to an
  account, force a partner, or exclude transactions.
* Duplicate import guard: possible duplicates are never auto-reconciled.
* Customer side only: money received is matched with customer invoices
  (customer credit notes are netted). Vendor bills and outgoing payments are out of scope.
* Manual matching wizard, small-difference write-offs, undo, activity log.
* Every reconciliation runs in a savepoint.
* Settings live in ir.config_parameter, never on res.company.
""",
    'depends': ['account', 'account_accountant'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/config_parameters.xml',
        'views/statement_line_views.xml',
        'views/apm_views.xml',
        'views/rule_views.xml',
        'views/excel_report_views.xml',
        'views/workspace_views.xml',
        'views/settings_links.xml',
        'views/menus.xml',
        'data/menu_placement.xml',
        'data/ir_cron.xml',
        'data/server_actions.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'auto_payment_matching/static/src/workspace/workspace.js',
            'auto_payment_matching/static/src/workspace/workspace.xml',
            'auto_payment_matching/static/src/workspace/workspace.scss',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
