from odoo import fields
from odoo.tests import tagged
from odoo.addons.account.tests.common import AccountTestInvoicingCommon

from ..utils import matching as mu


@tagged('post_install', '-at_install')
class TestAutoPaymentMatching(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls, chart_template_ref=None):
        super().setUpClass(chart_template_ref=chart_template_ref)
        cls.bank_journal = cls.company_data['default_journal_bank']
        icp = cls.env['ir.config_parameter'].sudo()
        icp.set_param('auto_payment_matching.mode', 'confident')
        icp.set_param('auto_payment_matching.auto_threshold', '90')
        icp.set_param('auto_payment_matching.suggest_threshold', '40')

    def _invoice(self, move_type='out_invoice', partner=None, amount=1000.0, date='2026-09-01'):
        return self.init_invoice(move_type, partner=partner or self.partner_a,
                                 invoice_date=fields.Date.from_string(date),
                                 amounts=[amount], post=True)

    def _st_line(self, amount, label, partner=None, date='2026-09-15'):
        return self.env['account.bank.statement.line'].create({
            'journal_id': self.bank_journal.id,
            'date': date,
            'payment_ref': label,
            'amount': amount,
            'partner_id': partner.id if partner else False,
        })

    # ------------------------------------------------------------------
    def test_reference_exact_auto_reconciles(self):
        invoice = self._invoice()
        st_line = self._st_line(invoice.amount_total, 'IBFT payment %s' % invoice.name, self.partner_a)
        st_line.action_auto_match()
        self.assertEqual(st_line.auto_match_status, 'matched')
        self.assertIn(invoice.payment_state, ('paid', 'in_payment'))
        self.assertTrue(st_line.is_reconciled)
        self.assertEqual(st_line.apm_log_ids[:1].status, 'success')

    def test_reference_with_separators_changed(self):
        invoice = self._invoice()
        glued = invoice.name.replace('/', '-').lower()
        st_line = self._st_line(invoice.amount_total, 'paid %s thanks' % glued, self.partner_a)
        st_line.action_auto_match()
        self.assertEqual(st_line.auto_match_status, 'matched')

    def test_partial_without_partner_becomes_suggestion(self):
        invoice = self._invoice()
        half = invoice.amount_total / 2
        st_line = self._st_line(half, 'part payment %s' % invoice.name)
        st_line.action_auto_match()
        self.assertEqual(st_line.auto_match_status, 'suggested')
        suggestion = st_line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1]
        self.assertEqual(suggestion.amount_kind, 'partial')
        suggestion.action_apply()
        self.assertEqual(suggestion.state, 'applied')
        self.assertEqual(invoice.payment_state, 'partial')
        self.assertAlmostEqual(invoice.amount_residual, invoice.amount_total - half)

    def test_one_payment_two_invoices_by_amount(self):
        inv1 = self._invoice(amount=1000.0, date='2026-08-01')
        inv2 = self._invoice(amount=2500.0, date='2026-08-10')
        self._invoice(amount=4000.0, date='2026-08-20')
        total = inv1.amount_total + inv2.amount_total
        st_line = self._st_line(total, 'payment received', self.partner_a)
        st_line.action_auto_match()
        suggestion = st_line.apm_suggestion_ids[:1]
        self.assertEqual(suggestion.strategy, 'partner_combination')
        self.assertEqual(set(suggestion.move_ids.ids), {inv1.id, inv2.id})

    def test_outgoing_payment_is_ignored(self):
        bill = self._invoice('in_invoice', partner=self.partner_b)
        st_line = self._st_line(-bill.amount_total, 'Transfer for %s' % bill.name, self.partner_b)
        self.assertFalse(st_line.auto_payment_available, 'money out is not handled by this module')
        st_line.action_auto_match()
        self.assertFalse(st_line.is_reconciled)
        self.assertEqual(bill.payment_state, 'not_paid')

    def test_vendor_bill_is_refused(self):
        bill = self._invoice('in_invoice', partner=self.partner_a)
        st_line = self._st_line(bill.amount_total, 'money in', self.partner_a)
        ok, _msg = st_line._apm_apply(bill.line_ids.filtered(
            lambda l: l.account_id.account_type == 'liability_payable'))
        self.assertFalse(ok)
        self.assertEqual(st_line.auto_match_status, 'error')
        self.assertFalse(st_line.is_reconciled, 'savepoint must roll back everything')

    def test_overpayment_keeps_credit_open_and_second_allocation(self):
        inv1 = self._invoice(amount=1000.0)
        st_line = self._st_line(inv1.amount_total + 500, 'pay %s' % inv1.name, self.partner_a)
        st_line.action_auto_match()
        self.assertEqual(st_line.auto_match_status, 'partial')
        self.assertAlmostEqual(st_line.auto_match_remaining_amount, 500)
        inv2 = self._invoice(amount=400.0)
        ok, _msg = st_line._apm_apply(inv2.line_ids.filtered(
            lambda l: l.account_id.account_type == 'asset_receivable'), source='manual')
        self.assertTrue(ok)
        self.assertAlmostEqual(st_line.auto_match_remaining_amount, 500 - inv2.amount_total)

    def test_undo(self):
        invoice = self._invoice()
        st_line = self._st_line(invoice.amount_total, invoice.name, self.partner_a)
        st_line.action_auto_match()
        self.assertTrue(st_line.is_reconciled)
        st_line.action_apm_undo()
        self.assertFalse(st_line.is_reconciled)
        self.assertEqual(st_line.auto_match_status, 'pending')
        self.assertEqual(invoice.payment_state, 'not_paid')

    def test_suggest_only_mode_never_reconciles(self):
        self.env['ir.config_parameter'].sudo().set_param('auto_payment_matching.mode', 'suggest')
        invoice = self._invoice()
        st_line = self._st_line(invoice.amount_total, invoice.name, self.partner_a)
        st_line.action_auto_match()
        self.assertEqual(st_line.auto_match_status, 'suggested')
        self.assertFalse(st_line.is_reconciled)

    def test_pure_helpers(self):
        idx = mu.TextIndex('IBFT INV202600012')
        self.assertEqual(idx.reference_hit(['INV/2026/00012', '', '']), 'strong')
        self.assertIsNone(idx.reference_hit(['INV/2026/0001', '', '']))
        subset, ambiguous = mu.find_subset([1000, 2500, 4000], 3500)
        self.assertEqual(subset, (0, 1))
        self.assertFalse(ambiguous)

    # ------------------------------------------------------------------
    def test_rule_books_bank_profit(self):
        self.env['ir.config_parameter'].sudo().set_param('auto_payment_matching.use_rules', 'True')
        charges = self.company_data['default_account_revenue']
        rule = self.env['auto.match.rule'].create({
            'name': 'Bank profit',
            'label_pattern': 'BANK PROFIT|PROFIT CREDIT',
            'direction': 'inbound',
            'action': 'book',
            'account_id': charges.id,
        })
        st_line = self._st_line(250.0, 'Monthly PROFIT CREDIT')
        st_line.action_auto_match()
        self.assertEqual(st_line.auto_match_status, 'matched')
        self.assertTrue(st_line.is_reconciled)
        self.assertIn(charges, st_line.move_id.line_ids.account_id)
        self.assertEqual(rule.match_count, 1)

    def test_rule_without_auto_apply_waits(self):
        self.env['ir.config_parameter'].sudo().set_param('auto_payment_matching.use_rules', 'True')
        rule = self.env['auto.match.rule'].create({
            'name': 'Profit (confirm)',
            'label_pattern': 'BANK PROFIT',
            'action': 'book',
            'account_id': self.company_data['default_account_revenue'].id,
            'auto_apply': False,
        })
        st_line = self._st_line(100.0, 'BANK PROFIT SEP')
        st_line.action_auto_match()
        self.assertEqual(st_line.apm_rule_id, rule)
        self.assertFalse(st_line.is_reconciled)
        st_line.action_apm_apply_rule()
        self.assertTrue(st_line.is_reconciled)

    def test_duplicate_is_never_auto_reconciled(self):
        invoice = self._invoice()
        first = self._st_line(invoice.amount_total, 'dup %s' % invoice.name, self.partner_a)
        second = self._st_line(invoice.amount_total, 'dup %s' % invoice.name, self.partner_a)
        second.action_auto_match()
        self.assertEqual(second.apm_duplicate_id, first)
        self.assertFalse(second.is_reconciled)
        self.assertEqual(second.auto_match_status, 'suggested')

    def test_menu_is_inside_accounting_app(self):
        menu = self.env.ref('auto_payment_matching.menu_auto_payment_matching')
        self.assertTrue(menu.parent_id)
        self.assertFalse(menu.parent_id.parent_id, 'menu must sit in an app top bar')

    def test_excel_report(self):
        invoice = self._invoice(amount=1000.0)
        partial_line = self._st_line(invoice.amount_total + 300, 'pay %s' % invoice.name, self.partner_a)
        partial_line.action_auto_match()
        pending_line = self._st_line(123.0, 'unknown money')
        money_out = self._st_line(-50.0, 'some expense')
        Report = self.env['auto.match.excel.report']

        month = Report.create({'period_type': 'month', 'months': '2026-09', 'status': 'all'})
        lines = month._get_lines()
        self.assertIn(partial_line, lines)
        self.assertIn(pending_line, lines, 'all stages must be exported, not only reconciled')
        self.assertNotIn(money_out, lines, 'only customer receipts are exported')
        self.assertEqual(month._line_status(partial_line), 'partial')
        self.assertIn(invoice, month._matched_documents(partial_line))
        url, name = month._create_attachment()
        self.assertTrue(url.startswith('/web/content/'))
        self.assertTrue(name.endswith('.xlsx'))

        only_partial = Report.create({'period_type': 'month', 'months': '2026-09', 'status': 'partial'})
        self.assertNotIn(pending_line, only_partial._get_lines())

        empty = Report.create({'period_type': 'month', 'months': '2025-01', 'status': 'all'})
        self.assertFalse(empty._get_lines())
        self.assertTrue(empty._create_attachment()[0], 'an empty period still produces a file')

        by_date = Report.create({'period_type': 'date', 'date_from': '2026-09-15', 'date_to': '2026-09-15'})
        self.assertIn(partial_line, by_date._get_lines())

        res = self.env['auto.match.workspace'].excel_report(
            {'period_type': 'month', 'months': ['2026-09'], 'status': 'all'})
        self.assertIn('url', res)

    # ------------------------------------------------------------------
    def test_workspace_invoice_reconcile_partial(self):
        ws = self.env['auto.match.workspace']
        invoice = self._invoice(amount=1000.0)
        rows = ws.get_invoices({'stage': 'open'})['rows']
        row = next(r for r in rows if r['id'] == invoice.id)
        self.assertEqual(row['stage'], 'pending')
        self.assertEqual(row['partner_payments'], 0, 'no payment from this partner yet')

        st_line = self._st_line(400.0, 'received', self.partner_a)
        row = next(r for r in ws.get_invoices({'stage': 'open'})['rows'] if r['id'] == invoice.id)
        self.assertTrue(row['can_reconcile'])
        payments = ws.get_invoice_payments(invoice.id)['payments']
        self.assertIn(st_line.id, [p['id'] for p in payments])

        res = ws.reconcile_invoice(invoice.id, st_line.id, 'partial')
        self.assertTrue(res['ok'], res['message'])
        self.assertEqual(invoice.payment_state, 'partial')
        self.assertEqual(st_line.apm_stage, 'full')
        row = next(r for r in ws.get_invoices({'stage': 'all'})['rows'] if r['id'] == invoice.id)
        self.assertEqual(row['stage'], 'partial')

    def test_workspace_auto_pays_selected_invoice_first(self):
        ws = self.env['auto.match.workspace']
        older = self._invoice(amount=500.0, date='2026-08-01')
        chosen = self._invoice(amount=700.0, date='2026-09-01')
        st_line = self._st_line(chosen.amount_total + older.amount_total, 'lump sum', self.partner_a)
        res = ws.reconcile_invoice(chosen.id, st_line.id, 'auto')
        self.assertTrue(res['ok'], res['message'])
        self.assertIn(chosen.payment_state, ('paid', 'in_payment'))
        self.assertIn(older.payment_state, ('paid', 'in_payment'))

    def test_workspace_records_and_manual_action(self):
        ws = self.env['auto.match.workspace']
        invoice = self._invoice(amount=1000.0)
        st_line = self._st_line(invoice.amount_total + 200, 'pay %s' % invoice.name, self.partner_a)
        st_line.action_auto_match()
        data = ws.get_records({})
        self.assertIn(st_line.id, [r['id'] for r in data['rows']])
        self.assertEqual(len(data['kpis']), 4)
        other = self._invoice(amount=100.0)
        action = ws.open_manual(st_line.id, other.id)
        self.assertEqual(action['res_model'], 'auto.match.manual.wizard')
        self.assertTrue(action['context']['apm_preselect_aml_ids'])
        self.assertTrue(ws.get_counts()['form_view_id'])

    def test_workspace_kpi_filters(self):
        ws = self.env['auto.match.workspace']
        inv1 = self._invoice(amount=1000.0)
        partial_line = self._st_line(inv1.amount_total + 200, 'pay %s' % inv1.name, self.partner_a)
        partial_line.action_auto_match()
        self.assertIn(partial_line.id, [r['id'] for r in ws.get_records({'stage': 'remaining'})['rows']])
        self.assertNotIn(partial_line.id, [r['id'] for r in ws.get_records({'stage': 'full'})['rows']])

        waiting = self._invoice(amount=300.0, partner=self.partner_b)
        self.assertNotIn(waiting.id, [r['id'] for r in ws.get_invoices({'stage': 'ready'})['rows']])
        self._st_line(50.0, 'deposit', self.partner_b)
        self.assertIn(waiting.id, [r['id'] for r in ws.get_invoices({'stage': 'ready'})['rows']])


    # ------------------------------------------------------------------ v5.3: name / amount / date
    def _partner(self, name):
        return self.env['res.partner'].create({'name': name, 'is_company': True})

    def _line_with_payer(self, amount, label, payer, date='2026-09-15'):
        return self.env['account.bank.statement.line'].create({
            'journal_id': self.bank_journal.id, 'date': date, 'payment_ref': label,
            'amount': amount, 'partner_name': payer})

    def test_v53_similar_payer_name_identifies_customer(self):
        cust = self._partner('Al-Noor Traders')
        inv = self._invoice(partner=cust, amount=700.0)
        line = self._line_with_payer(inv.amount_total, 'IBFT TRANSFER', 'AL NOOR TRADERS')
        partner, how, points = line._apm_identify()
        self.assertEqual(partner, cust)
        self.assertIn('similar', how)
        self.assertEqual(points, 12)
        line.action_auto_match()
        best = line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1]
        self.assertEqual(best.move_ids, inv)
        self.assertLess(best.score, 90, 'a name alone never reconciles automatically')

    def test_v53_customer_name_in_label(self):
        cust = self._partner('Margalla Builders')
        self._invoice(partner=cust, amount=900.0)
        line = self._st_line(500.0, 'IBFT MARGALLA BUILDERS ISB')
        partner, how, _points = line._apm_identify()
        self.assertEqual(partner, cust)
        self.assertIn('label', how)

    def test_v53_near_tie_names_are_not_guessed(self):
        a = self._partner('Pak Steel Works')
        b = self._partner('Pak Steel Mills')
        self._invoice(partner=a, amount=100.0)
        self._invoice(partner=b, amount=200.0)
        line = self._line_with_payer(50.0, 'TRANSFER', 'PAK STEEL')
        partner, _how, _points = line._apm_identify()
        self.assertFalse(partner, 'two equally similar customers: do not pick one')

    def test_v53_amount_only_ranked_by_date(self):
        # own customers without payment terms: one receivable line per invoice
        far = self._invoice(partner=self._partner('Far Due Co'), amount=1111.0, date='2026-07-01')
        near = self._invoice(partner=self._partner('Near Due Co'), amount=1111.0, date='2026-09-10')
        line = self._st_line(near.amount_total, 'CASH DEPOSIT')
        line.action_auto_match()
        self.assertEqual(line.auto_match_status, 'suggested')
        best = line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending').sorted(lambda s: -s.score)[:1]
        self.assertEqual(best.move_ids, near, 'the invoice due closest to the payment comes first')
        self.assertLess(best.score, 90)
        self.assertNotIn(far.payment_state, ('paid', 'in_payment'))

    def test_v53_invoice_after_payment_lowers_confidence(self):
        inv = self._invoice(amount=800.0, date='2026-09-20')
        line = self._st_line(inv.amount_total, 'IBFT %s' % inv.name, self.partner_a, date='2026-09-15')
        line._apm_run(allow_apply=False)
        reasons = line.apm_suggestion_ids.filtered(lambda s: s.state == 'pending')[:1].reasons or ''
        self.assertIn('dated after the payment', reasons)

    def test_v53_rules_are_off_by_default(self):
        rule = self.env['auto.match.rule'].create({
            'name': 'Profit', 'label_pattern': 'BANK PROFIT', 'action': 'book',
            'account_id': self.company_data['default_account_revenue'].id})
        line = self._st_line(100.0, 'BANK PROFIT SEP')
        line.action_auto_match()
        self.assertFalse(line.is_reconciled, 'rules only run when switched on in Settings')
        self.assertEqual(rule.match_count, 0)

    def test_v53_manual_action_opens_from_workspace(self):
        inv = self._invoice()
        line = self._st_line(inv.amount_total, 'any')
        action = self.env['auto.match.workspace'].open_manual(line.id, inv.id)
        self.assertTrue(action.get('views'), "the web client needs 'views' (otherwise: reading 'map')")

    def test_v53_activity_log_is_append_only(self):
        inv = self._invoice()
        line = self._st_line(inv.amount_total, inv.name, self.partner_a)
        line.action_auto_match()
        log = line.apm_log_ids[:1]
        manager = self.env['res.users'].create({
            'name': 'Accounting manager', 'login': 'apm_v53_manager',
            'groups_id': [(6, 0, [self.env.ref('account.group_account_manager').id])]})
        with self.assertRaises(Exception):
            log.with_user(manager).write({'message': 'changed'})
