/** @odoo-module **/

import { Component, onWillStart, useExternalListener, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";

const MODEL = "auto.match.workspace";
const PAGE_SIZE = 25;

// A function, so translations are looked up at render time, not at import.
function stageLabels() {
    return {
        pending: _t("Pending"),
        partial: _t("Partially Reconciled"),
        full: _t("Fully Reconciled"),
    };
}

// ---------------------------------------------------------------------------
// Reconcile dialog: pick a payment for an invoice, then choose how to match
// ---------------------------------------------------------------------------
export class ApmReconcileDialog extends Component {
    static template = "auto_payment_matching.ReconcileDialog";
    static components = { Dialog };
    static props = ["invoiceId", "onDone", "close"];

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.notification = useService("notification");
        this.state = useState({ data: null, selected: null, busy: false });
        onWillStart(async () => {
            this.state.data = await this.orm.call(MODEL, "get_invoice_payments", [this.props.invoiceId]);
            const first = this.state.data.payments[0];
            this.state.selected = first ? first.id : null;
        });
    }

    stageLabel(stage) {
        return stageLabels()[stage] || stage;
    }

    select(id) {
        this.state.selected = id;
    }

    async reconcile(mode) {
        if (!this.state.selected || this.state.busy) {
            return;
        }
        this.state.busy = true;
        try {
            const res = await this.orm.call(MODEL, "reconcile_invoice", [
                this.props.invoiceId,
                this.state.selected,
                mode,
            ]);
            this.notification.add(res.message, { type: res.ok ? "success" : "danger" });
            if (res.ok) {
                this.props.close();
                this.props.onDone();
            }
        } finally {
            this.state.busy = false;
        }
    }

    async manual() {
        if (!this.state.selected) {
            return;
        }
        const action = await this.orm.call(MODEL, "open_manual", [this.state.selected, this.props.invoiceId]);
        this.props.close();
        await this.action.doAction(action, { onClose: () => this.props.onDone() });
    }
}

// ---------------------------------------------------------------------------
// Workspace
// ---------------------------------------------------------------------------
export class ApmWorkspace extends Component {
    static template = "auto_payment_matching.Workspace";
    static props = ["*"];

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.dialog = useService("dialog");
        this.notification = useService("notification");
        this.state = useState({
            page: "reconcile",
            tab: "invoices",
            search: "",
            stage: "open",
            order: "date desc",
            offset: 0,
            data: null,
            counts: {},
            loading: false,
            menuFor: null,
            busyRow: null,
            excel: {
                period_type: "month",
                year: new Date().getFullYear(),
                months: [],
                thisMonth: "",
                date_from: "",
                date_to: "",
                status: "all",
                busy: false,
            },
        });
        this._searchTimer = null;
        useExternalListener(window, "click", () => {
            this.state.menuFor = null;
        });
        onWillStart(async () => {
            const defaults = await this.orm.call(MODEL, "excel_defaults", []);
            Object.assign(this.state.excel, {
                date_from: defaults.date_from,
                date_to: defaults.date_to,
                year: defaults.year,
                thisMonth: defaults.month_key,
                months: [defaults.month_key],
            });
            await this.reload();
        });
    }

    // ---- navigation ------------------------------------------------------
    get navItems() {
        const c = this.state.counts;
        return [
            { key: "reconcile", label: _t("Transactions to Reconcile"), icon: "fa-exchange", count: c.invoices },
            { key: "records", label: _t("Transaction Records"), icon: "fa-credit-card", count: null },
            { key: "review", label: _t("Review Transactions"), icon: "fa-check-square-o", count: c.review },
            { key: "excel", label: _t("Excel Report"), icon: "fa-file-excel-o", count: null },
        ];
    }

    get pageInfo() {
        return {
            reconcile: {
                title: _t("Transactions to Reconcile"),
                subtitle: _t("Open customer invoices, and customer receipts still waiting to be matched."),
                icon: "fa-exchange",
            },
            records: {
                title: _t("Transaction Records"),
                subtitle: _t("Track every customer receipt with its matching stage and balances."),
                icon: "fa-credit-card",
            },
            review: {
                title: _t("Review Transactions"),
                subtitle: _t("Matches the system found but did not apply on its own. Apply or reject them."),
                icon: "fa-check-square-o",
            },
            excel: {
                title: _t("Excel Report"),
                subtitle: _t("Download customer receipts with their stage and the invoices they settled."),
                icon: "fa-file-excel-o",
            },
        }[this.state.page];
    }

    get stageOptions() {
        const s = this.state;
        const STAGE_LABELS = stageLabels();
        if (s.page === "reconcile" && s.tab === "invoices") {
            return [
                { value: "open", label: _t("Pending + Partially Reconciled") },
                { value: "pending", label: STAGE_LABELS.pending },
                { value: "partial", label: STAGE_LABELS.partial },
                { value: "ready", label: _t("Receipt received") },
                { value: "full", label: STAGE_LABELS.full },
                { value: "all", label: _t("All stages") },
            ];
        }
        if (s.page === "reconcile") {
            return [
                { value: "all", label: _t("All open receipts") },
                { value: "pending", label: STAGE_LABELS.pending },
                { value: "partial", label: STAGE_LABELS.partial },
            ];
        }
        if (s.page === "records") {
            return [
                { value: "all", label: _t("All stages") },
                { value: "full", label: STAGE_LABELS.full },
                { value: "partial", label: STAGE_LABELS.partial },
                { value: "remaining", label: _t("With remaining amount") },
            ];
        }
        return [];
    }

    defaultStage() {
        const s = this.state;
        return s.page === "reconcile" && s.tab === "invoices" ? "open" : "all";
    }

    async go(page) {
        if (page === this.state.page) {
            return;
        }
        Object.assign(this.state, { page, offset: 0, search: "", order: "date desc", data: null });
        this.state.stage = this.defaultStage();
        await this.reload();
    }

    async setTab(tab) {
        if (tab === this.state.tab) {
            return;
        }
        Object.assign(this.state, { tab, offset: 0, data: null });
        this.state.stage = this.defaultStage();
        await this.reload();
    }

    // ---- data -------------------------------------------------------------
    get method() {
        const s = this.state;
        if (s.page === "reconcile") {
            return s.tab === "invoices" ? "get_invoices" : "get_bank_open";
        }
        return { records: "get_records", review: "get_review" }[s.page];
    }

    async reload() {
        const s = this.state;
        s.loading = true;
        try {
            s.counts = await this.orm.call(MODEL, "get_counts", []);
            if (this.method) {
                s.data = await this.orm.call(MODEL, this.method, [{
                    search: s.search,
                    stage: s.stage,
                    order: s.order,
                    offset: s.offset,
                    limit: PAGE_SIZE,
                }]);
            } else {
                s.data = null;
            }
        } finally {
            s.loading = false;
        }
    }

    onSearchInput(ev) {
        this.state.search = ev.target.value;
        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(() => {
            this.state.offset = 0;
            this.reload();
        }, 350);
    }

    async onStage(ev) {
        this.state.stage = ev.target.value;
        this.state.offset = 0;
        await this.reload();
    }

    // ---- KPI cards act as filters ----------------------------------------
    kpiStage(kpi) {
        const map = {
            // Transaction Records cards
            total: "all",
            full: "full",
            remaining: "remaining",
            // Customer Invoices cards
            open: "open",
            pending: "pending",
            ready: "ready",
        };
        // "partial" means the same on both pages
        return kpi.key === "partial" ? "partial" : map[kpi.key];
    }

    isKpiActive(kpi) {
        return this.kpiStage(kpi) === this.state.stage;
    }

    async onKpi(kpi) {
        const stage = this.kpiStage(kpi);
        if (!stage) {
            return;
        }
        this.state.stage = stage;
        this.state.offset = 0;
        await this.reload();
    }

    sortIcon(field) {
        const [f, dir] = this.state.order.split(" ");
        if (f !== field) {
            return "fa-sort text-muted";
        }
        return dir === "asc" ? "fa-sort-asc" : "fa-sort-desc";
    }

    async sortBy(field) {
        const [f, dir] = this.state.order.split(" ");
        this.state.order = `${field} ${f === field && dir === "desc" ? "asc" : "desc"}`;
        this.state.offset = 0;
        await this.reload();
    }

    // ---- pager ------------------------------------------------------------
    get pager() {
        const total = (this.state.data && this.state.data.total) || 0;
        const from = total ? this.state.offset + 1 : 0;
        const to = Math.min(this.state.offset + PAGE_SIZE, total);
        return {
            total,
            from,
            to,
            page: Math.floor(this.state.offset / PAGE_SIZE) + 1,
            hasPrev: this.state.offset > 0,
            hasNext: to < total,
        };
    }

    async prevPage() {
        this.state.offset = Math.max(0, this.state.offset - PAGE_SIZE);
        await this.reload();
    }

    async nextPage() {
        this.state.offset += PAGE_SIZE;
        await this.reload();
    }

    // ---- helpers ------------------------------------------------------------
    stageLabel(stage) {
        return stageLabels()[stage] || stage;
    }

    toggleMenu(ev, id) {
        ev.stopPropagation();
        this.state.menuFor = this.state.menuFor === id ? null : id;
    }

    notify(res) {
        if (res && res.message) {
            this.notification.add(res.message, { type: res.ok ? "success" : "danger" });
        }
    }

    async runRow(id, fn) {
        if (this.state.busyRow) {
            return;
        }
        this.state.busyRow = id;
        try {
            await fn();
        } finally {
            this.state.busyRow = null;
        }
    }

    // ---- actions ---------------------------------------------------------
    openInvoice(id) {
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "account.move",
            res_id: id,
            views: [[false, "form"]],
            target: "current",
        });
    }

    openTransaction(id) {
        this.state.menuFor = null;
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "account.bank.statement.line",
            res_id: id,
            views: [[this.state.counts.form_view_id || false, "form"]],
            target: "current",
        });
    }

    openReconcile(row) {
        this.dialog.add(ApmReconcileDialog, {
            invoiceId: row.id,
            onDone: () => this.reload(),
        });
    }

    async autoMatch(row) {
        await this.runRow(row.id, async () => {
            this.notify(await this.orm.call(MODEL, "bank_action", [row.id, "auto"]));
            await this.reload();
        });
    }

    async manualMatch(row) {
        this.state.menuFor = null;
        const action = await this.orm.call(MODEL, "open_manual", [row.id, false]);
        await this.action.doAction(action, { onClose: () => this.reload() });
    }

    async undo(row) {
        this.state.menuFor = null;
        await this.runRow(row.id, async () => {
            this.notify(await this.orm.call(MODEL, "bank_action", [row.id, "undo"]));
            await this.reload();
        });
    }

    async review(row, what) {
        await this.runRow(row.id, async () => {
            this.notify(await this.orm.call(MODEL, "review_action", [row.id, what]));
            await this.reload();
        });
    }

    // ---- excel ----------------------------------------------------------
    get monthCells() {
        const ex = this.state.excel;
        const cells = [];
        for (let m = 0; m < 12; m++) {
            const key = `${ex.year}-${String(m + 1).padStart(2, "0")}`;
            cells.push({
                key,
                label: new Date(ex.year, m, 1).toLocaleString(undefined, { month: "short" }),
                selected: ex.months.includes(key),
                current: key === ex.thisMonth,
            });
        }
        return cells;
    }

    get selectedMonthsText() {
        const months = [...this.state.excel.months].sort();
        if (!months.length) {
            return _t("No month selected");
        }
        return months
            .map((key) => {
                const [y, m] = key.split("-").map(Number);
                return new Date(y, m - 1, 1).toLocaleString(undefined, { month: "short", year: "numeric" });
            })
            .join(", ");
    }

    setPeriodType(type) {
        this.state.excel.period_type = type;
    }

    shiftYear(delta) {
        this.state.excel.year += delta;
    }

    toggleMonth(key) {
        const months = this.state.excel.months;
        const index = months.indexOf(key);
        if (index >= 0) {
            months.splice(index, 1);
        } else {
            months.push(key);
        }
    }

    selectWholeYear() {
        const ex = this.state.excel;
        const keys = this.monthCells.map((c) => c.key);
        ex.months = [...new Set([...ex.months.filter((k) => !k.startsWith(`${ex.year}-`)), ...keys])];
    }

    selectThisMonth() {
        const ex = this.state.excel;
        ex.months = [ex.thisMonth];
        ex.year = Number(ex.thisMonth.split("-")[0]);
    }

    clearMonths() {
        this.state.excel.months = [];
    }

    async downloadExcel() {
        const ex = this.state.excel;
        if (ex.busy) {
            return;
        }
        if (ex.period_type === "month" && !ex.months.length) {
            this.notification.add(_t("Select at least one month."), { type: "warning" });
            return;
        }
        if (ex.period_type === "date" && (!ex.date_from || !ex.date_to)) {
            this.notification.add(_t("Choose both dates."), { type: "warning" });
            return;
        }
        ex.busy = true;
        try {
            const res = await this.orm.call(MODEL, "excel_report", [{
                period_type: ex.period_type,
                months: [...ex.months].sort(),
                date_from: ex.date_from,
                date_to: ex.date_to,
                status: ex.status,
            }]);
            // A plain link click downloads the attachment without leaving the page.
            const link = document.createElement("a");
            link.href = res.url;
            link.download = res.name;
            document.body.appendChild(link);
            link.click();
            link.remove();
            this.notification.add(_t("Excel file is downloading: ") + res.name, { type: "success" });
        } finally {
            ex.busy = false;
        }
    }
}

registry.category("actions").add("apm_workspace", ApmWorkspace);
